# assistance controller
class AssistancesController < ApplicationController
  before_action :require_login, only: [:edit, :update, :new, :destroy]


  def index
    @assistances = Assistance.all
  end

  def show
    @assistance = Assistance.find(params[:id])
  end

  def new
    @assistance = Assistance.new
  end

  def edit
    @assistance = Assistance.find(params[:id])
  end

  def create
    @assistance = Assistance.new(assistance_params)
    upload_file
    if @assistance.save
      flash[:success] = 'Assistência criada com sucesso'
      redirect_to assistances_path
    else
      render 'new'
    end
  end

  def update
    @assistance = Assistance.find(params[:id])

    @file = params[:assistance]
    upload_file if @file[:file].present?

    if @assistance.update(assistance_params)
      flash[:success] = 'Assistência atualizada com sucesso'
      redirect_to @assistance
    else
      render 'edit'
    end
  end

  def destroy
    @assistance = Assistance.find(params[:id])
    @assistance.destroy
    flash[:success] = 'Assistência apagada com sucesso'
    redirect_to assistances_path
  end

  def upload_file
    @file = params[:assistance] # hash que contem tudo

    return if @file[:file].nil?
    @tempfile = @file[:file].tempfile # encontrando o caminho do tempfile
    @geojson = File.read(@tempfile) # lendo o conteudo da tempfile
    @assistance.geojson = @geojson # passando a hash para a coluna geojson
  end

  private

  def assistance_params
    params.require(:assistance).permit(:name, :address, :phone,
                                       :latitude, :longitude, :geojson,
                                       :assist_type)
  end
end
