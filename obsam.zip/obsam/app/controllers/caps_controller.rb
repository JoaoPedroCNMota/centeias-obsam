# Caps Controller
class CapsController < ApplicationController
  def index
    @caps = Cap.all
  end

  def show
    @caps = Cap.find(params[:id])
    @devices = Device.all
  end
end
