# CapsRequests Controller
class CapsRequestsController < ApplicationController
  include CapsRequestsHelper
  before_action :require_login

  def index
    @request = CapsRequest.all
    @users = User.all
  end

  def show
    @request = CapsRequest.find(params[:id])
    @users = User.all

    @caps = Cap.find(@request.caps_id) if Cap.exists?(@request.caps_id) &&
                                          @request.request_type != 1
  end

  def new
    @request = CapsRequest.new
  end

  def create
    @request = CapsRequest.new(request_params)
    @request.user_id = current_user.id
    @request.request_type = 1
    @modality = modality_holder
    if @request.save
      flash[:success] = 'Solicitação de novo CAPS enviada ao administrador'
      redirect_to @request
    else
      render 'new'
    end
  end

  def edit
    session[:caps_id] = params[:id]
    @request = CapsRequest.new
  end

  def update_caps
    @request = CapsRequest.new(request_params)
    @request.user_id = current_user.id
    @request.caps_id = session[:caps_id]
    @request.request_type = 2
    if @request.save
      flash[:success] = 'Solicitação de edição enviada ao administrador'
      redirect_to @request
    else
      render 'edit'
    end
  end

  def destroy_request
    session[:caps_id] = params[:id]
    @request = CapsRequest.new
  end

  def destruction_request
    @request = CapsRequest.new(request_params)
    @request.user_id = current_user.id
    @request.caps_id = session[:caps_id]
    @request.request_type = 3
    if @request.save
      flash[:success] = 'Solicitação de remoção enviada ao administrador'
      redirect_to @request
    else
      render 'destroy_request'
    end
  end

  def destroy
    @request = CapsRequest.find(params[:id])
    @request.destroy
    redirect_to caps_requests_path
  end

  def accept
    @request = CapsRequest.find(params[:id])
    @request.update(status: 1)

    check_type

    flash[:success] = 'A solicitação foi aceita'
    redirect_to caps_requests_path
  end

  def refuse
    @request = CapsRequest.find(params[:id])
    @request.update(status: 0)

    flash[:danger] = 'A solicitação foi recusada'
    redirect_to caps_requests_path
  end

  private

  def request_params
    params.require(:caps_request).permit(:user_id, :description, :request_type,
                                         :status, :caps_id, :unit, :name,
                                         :address, :ad_region, :modality,
                                         :phone, :coverage_area, :latitude,
                                         :longitude, :caps_description,
                                         :working_hours)
  end
end
