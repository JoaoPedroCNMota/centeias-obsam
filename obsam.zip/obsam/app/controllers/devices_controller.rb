# Devices Controller
class DevicesController < ApplicationController
  def index
    @device = Device.all
  end

  def show
    @device = Device.find(params[:id])
    @caps = Cap.all
  end
end
