# Devices Requests Controller
class DevicesRequestsController < ApplicationController
  include DevicesRequestsHelper
  before_action :require_login

  def index
    @request = DevicesRequest.all
    @users   = User.all
  end

  def show
    @request = DevicesRequest.find(params[:id])
    @caps = Cap.all
    @users = User.all
    @device = Device.find(@request.device_id) if
      Device.exists?(@request.device_id) && @request.request_type != 1
  end

  def new
    @request = DevicesRequest.new
    @caps = Cap.all
  end

  def create
    creation_definition
    @request.request_type = 1
    if @request.save
      flash[:success] = 'Solicitação de novo Dispositivo
                         enviada ao administrador'
      redirect_to @request
    else
      render 'new'
    end
  end

  def edit
    session[:device_id] = params[:id]
    @request = DevicesRequest.new
    @caps = Cap.all
  end

  def update_device
    creation_definition
    @request.device_id = session[:device_id]
    @request.request_type = 2
    if @request.save
      flash[:success] = 'Solicitação de edição enviada ao administrador'
      redirect_to @request
    else
      render 'edit'
    end
  end

  def destroy_request
    session[:device_id] = params[:id]
    @request = DevicesRequest.new
  end

  def destruction_request
    @request = DevicesRequest.new(request_params)
    @request.user_id = current_user.id
    @request.device_id = session[:device_id]
    @request.request_type = 3
    if @request.save
      flash[:success] = 'Solicitação de remoção enviada ao administrador'
      redirect_to @request
    else
      render 'destroy_request'
    end
  end

  def destroy
    @request = DevicesRequest.find(params[:id])
    @request.destroy
    redirect_to devices_requests_path
  end

  def accept
    @request = DevicesRequest.find(params[:id])
    @request.update(status: 1)

    check_type

    flash[:success] = 'A solicitação foi aceita'
    redirect_to devices_requests_path
  end

  def refuse
    @request = DevicesRequest.find(params[:id])
    @request.update(status: 0)

    flash[:danger] = 'A solicitação foi recusada'
    redirect_to devices_requests_path
  end

  private

  def request_params
    params.require(:devices_request).permit(:user_id, :description,
                                            :request_type, :status, :caps_id,
                                            :device_id, :name, :address,
                                            :city, :uf, :cep, :phone1, :phone2,
                                            :email, :website, :public_policy,
                                            :operation_days, :working_hours,
                                            :target_audience, :ad_area,
                                            :first_attendance_time, :longitude,
                                            :first_attendance_documentation,
                                            :device_description, :latitude)
  end
end
