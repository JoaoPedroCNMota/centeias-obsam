class NasfsController < ApplicationController
  before_action :set_nasf, only: [:show, :edit, :update, :destroy]

  def index
    @nasfs = Nasf.all
    @ubs = Ub.all
  end

  # GET /nasfs/1
  # GET /nasfs/1.json
  def show
    @nasf = Nasf.find(params[:id])
    @ubs = Ub.all
  end

  # GET /nasfs/new
  def new
    @nasf = Nasf.new
  end

  # GET /nasfs/1/edit
  def edit
    @nasf = Nasf.find(params[:id])
  end

  # POST /nasfs
  # POST /nasfs.json
  def create
    @nasf = Nasf.new(nasf_params)
    upload_file
     if @nasf.save
       flash[:success] = 'NASF criado com sucesso'
       redirect_to nasfs_path
    else
      render 'new'
    end
  end

  # PATCH/PUT /nasfs/1
  # PATCH/PUT /nasfs/1.json
  def update
    @nasf = Nasf.find(params[:id])

    @file = params[:nasf]
    upload_file if @file[:file].present?

    if @nasf.update(nasf_params)
      flash[:success] = 'NASF atualizado com sucesso'
      redirect_to @nasf
     else
      render 'edit'
     end
  end

  # DELETE /nasfs/1
  # DELETE /nasfs/1.json
  def destroy
    @nasf = Nasf.find(params[:id])
    @nasf.destroy
    flash[:success] = 'NASF apagado com sucesso'
    redirect_to nasfs_path
  end

  def upload_file
    @file = params[:nasf] # hash que contem tudo

    return if @file[:file].nil?
    @tempfile = @file[:file].tempfile # encontrando o caminho do tempfile
    @geojson = File.read(@tempfile) # lendo o conteudo da tempfile
    @nasf.geojson = @geojson # passando a hash para a coluna geojson
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_nasf
      @nasf = Nasf.find(params[:id])
    end

    # Never trust parameters from the scary internet, only allow the white list through.
    def nasf_params
      params.require(:nasf).permit(:nasf_type, :lotation, :ubs, :team,
                                   :specialties, :health_region, :geojson)
    end
end