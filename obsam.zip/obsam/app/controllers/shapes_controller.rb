# controller shape
class ShapesController < ApplicationController
  include DevicesRequestsHelper
  before_action :require_admin

  def index
    @shapes = Shape.all
    @caps = Cap.all
  end

  def show
    @shape = Shape.find(params[:id])
  end

  def new
    @shape = Shape.new
    @caps = Cap.all
  end

  def create
    upload_file
    if !@json.nil? && @json['features'][0]['geometry']['type'] != 'Polygon'
      create_from_file
    elsif @shape.save
      flash[:success] = 'Shape criado'
      redirect_to shapes_path
    else
      render 'new'
    end
  end

  def destroy
    @shape = Shape.find(params[:id])
    @shape.destroy
    flash[:success] = 'Shape apagado com sucesso'
    redirect_to shapes_path
  end

  def upload_file
    @shape = Shape.new(shape_params)
    @file = params[:shape] # hash que contem tudo

    return if @file[:file].nil?
    @tempfile = @file[:file].tempfile # encontrando o caminho do tempfile
    @geojson = File.read(@tempfile) # lendo o conteudo da tempfile
    @shape.geojson = @geojson # passando a hash para a coluna geojson
    @json = JSON.parse(@geojson)
  end

  def create_from_file
    @json['features'].each do |shape|
       create_device_from_file(shape, @shape.cap_id)
    end
    redirect_to devices_path
  end

  private

  def shape_params
    params.require(:shape).permit(:cap_id, :geojson)
  end
end
