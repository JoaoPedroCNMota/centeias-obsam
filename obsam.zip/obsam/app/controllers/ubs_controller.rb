class UbsController < ApplicationController
  before_action :set_ub, only: [:show, :edit, :update, :destroy] 

  def index
    @ubs = Ub.all
  end

  # GET /ubs/1
  # GET /ubs/1.json
  def show
    @ub = Ub.find(params[:id])
  end

  # GET /ubs/new
  def new
    @ub = Ub.new
  end

  # GET /ubs/1/edit
  def edit
    @ub = Ub.find(params[:id])
  end

  # POST /ubs
  # POST /ubs.json
  def create
    @ub = Ub.new(ub_params)
    upload_file
    if @ub.save
      flash[:success] = 'UBS criada com sucesso'
      redirect_to ubs_path
    else
      render 'new'
    end
  end

  # PATCH/PUT /ubs/1
  # PATCH/PUT /ubs/1.json
  def update
      @ub = Ub.find(params[:id])

      @file = params[:ub]
      upload_file if @file[:file].present?

    if @ub.update(ub_params)
      flash[:success] = 'UBS atualizada com sucesso'
      redirect_to @ub
    else
      render 'edit'
    end
  end

  # DELETE /ubs/1
  # DELETE /ubs/1.json
  def destroy
    @ub = Ub.find(params[:id])
    @ub.destroy
    flash[:success] = 'UBS apagada com sucesso'
    redirect_to ubs_path
  end

  def upload_file
    @file = params[:ub] # hash que contem tudo

    return if @file[:file].nil?
    @tempfile = @file[:file].tempfile # encontrando o caminho do tempfile
    @geojson = File.read(@tempfile) # lendo o conteudo da tempfile
    @ub.geojson = @geojson # passando a hash para a coluna geojson
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_ub
      @ub = Ub.find(params[:id])
    end

    # Never trust parameters from the scary internet, only allow the white list through.
    def ub_params
      params.require(:ub).permit(:cnes, :name, :adress, :cep,
                                 :unity_type, :working_hours, :drugstore,
                                :dental_care, :latitude, :longitude, :geojson, :phone1, :health_region)
    end
end
