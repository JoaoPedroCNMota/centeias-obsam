# controller user
class UsersController < ApplicationController
  before_action :require_admin

  def index
    @users = User.all
  end

  def new
    @user = User.new
  end

  def edit
    @user = User.find(params[:id])
  end

  def create
    @user = User.new(user_params)
    if @user.save
      flash[:success] = 'Conta criada com sucesso'
      redirect_to signup_path
    else
      render 'new'
    end
  end

  def update
    @user = User.find(params[:id])

    if @user.update(user_params)
      flash[:success] = 'Conta atualizada com sucesso'
      redirect_to @user
    else
      render 'edit'
    end
  end

  def destroy
    @user = User.find(params[:id])
    @user.destroy
    flash[:success] = 'Conta apagada com sucesso'
    redirect_to users_path
  end

  private

  def user_params
    params.require(:user).permit(:name, :username, :password,
                                 :password_confirmation, :admin)
  end
end
