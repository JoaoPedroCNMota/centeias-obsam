# controller welcome
class WelcomeController < ApplicationController
  def home
    # Controller of the home page
    @caps = Cap.all
    @ubs = Ub.all

  end
end
