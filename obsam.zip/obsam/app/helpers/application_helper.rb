# Base class with the methods used by most views
module ApplicationHelper
end
