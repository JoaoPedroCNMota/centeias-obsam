# This helper contains some useful methods for
# creation of all the three types of requests
module CapsRequestsHelper
  def check_type
    if @request.request_type == 1
      create_caps
    elsif @request.request_type == 2
      edit_caps
    else
      refuse_automatically
      destroy_caps
    end
  end

  # rubocop:disable Metrics/MethodLength
  def create_caps
    @caps = Cap.create(unit:             @request.unit,
                       name:             @request.name,
                       address:          @request.address,
                       ad_region:        @request.ad_region,
                       modality:         @request.modality,
                       phone:            @request.phone,
                       coverage_area:    @request.coverage_area,
                       caps_description: @request.caps_description,
                       latitude:         @request.latitude,
                       longitude:        @request.longitude,
                       working_hours:    @request.working_hours)
  end

  def edit_caps
    @caps = Cap.find(@request.caps_id)
    @caps.update(unit:             @request.unit,
                 name:             @request.name,
                 address:          @request.address,
                 ad_region:        @request.ad_region,
                 modality:         @request.modality,
                 phone:            @request.phone,
                 coverage_area:    @request.coverage_area,
                 caps_description: @request.caps_description,
                 latitude:         @request.latitude,
                 longitude:        @request.longitude,
                 working_hours:    @request.working_hours)
  end
  # rubocop:enable Metrics/MethodLength

  def destroy_caps
    @caps = Cap.find(@request.caps_id)
    @caps.destroy
  end

  def refuse_automatically
    @refuse = CapsRequest.all
    @refuse.each do |request|
      request.update(status: 0) if request.caps_id == @request.caps_id &&
                                   request.id != @request.id &&
                                   request.status == 2
    end
  end

  def modality_holder
    params[:caps_request][:modality] unless
      params[:caps_request][:modality].nil?
  end
end
