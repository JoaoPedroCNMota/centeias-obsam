# This helper contains some useful methods for
# creation of all the three types of requests
module DevicesRequestsHelper # rubocop:disable Metrics/ModuleLength
  def check_type
    if @request.request_type == 1
      create_device
    elsif @request.request_type == 2
      edit_device
    else
      refuse_automatically
      destroy_device
    end
  end

  # rubocop:disable Metrics/AbcSize
  def creation_definition
    @caps = Cap.all
    @request = DevicesRequest.new(request_params)
    @request.user_id = current_user.id
    request_params = params[:devices_request]
    @request.public_policy = request_params[:other] if
      request_params[:public_policy] == 'Outros'
    @caps_holder = caps_holder
    @policy_holder = policy_holder
    @other_holder = other_holder
  end
  # rubocop:enable Metrics/AbcSize

  def caps_holder
    params[:devices_request][:caps_id] unless
      params[:devices_request][:caps_id].nil?
  end

  def policy_holder
    params[:devices_request][:public_policy] unless
      params[:devices_request][:public_policy].nil?
  end

  def other_holder
    params[:devices_request][:other] unless
      params[:devices_request][:other].nil?
  end

  # rubocop:disable Metrics/AbcSize, Metrics/MethodLength, Metrics/LineLength
  def create_device
    @device = Device.create(caps_id:                        @request.caps_id,
                            name:                           @request.name,
                            address:                        @request.address,
                            city:                           @request.city,
                            uf:                             @request.uf,
                            cep:                            @request.cep,
                            phone1:                         @request.phone1,
                            phone2:                         @request.phone2,
                            email:                          @request.email,
                            website:                        @request.website,
                            public_policy:                  @request.public_policy,
                            operation_days:                 @request.operation_days,
                            working_hours:                  @request.working_hours,
                            target_audience:                @request.target_audience,
                            ad_area:                        @request.ad_area,
                            first_attendance_time:          @request.first_attendance_time,
                            first_attendance_documentation: @request.first_attendance_documentation,
                            device_description:             @request.device_description,
                            latitude:                       @request.latitude,
                            longitude:                      @request.longitude)
  end

  def edit_device
    @device = Device.find(@request.device_id)
    @device.update(caps_id:                        @request.caps_id,
                   name:                           @request.name,
                   address:                        @request.address,
                   city:                           @request.city,
                   uf:                             @request.uf,
                   cep:                            @request.cep,
                   phone1:                         @request.phone1,
                   phone2:                         @request.phone2,
                   email:                          @request.email,
                   website:                        @request.website,
                   public_policy:                  @request.public_policy,
                   operation_days:                 @request.operation_days,
                   working_hours:                  @request.working_hours,
                   target_audience:                @request.target_audience,
                   ad_area:                        @request.ad_area,
                   first_attendance_time:          @request.first_attendance_time,
                   first_attendance_documentation: @request.first_attendance_documentation,
                   device_description:             @request.device_description,
                   latitude:                       @request.latitude,
                   longitude:                      @request.longitude)
  end

  def create_device_from_file(shape, caps_id)
    properties = shape['properties']
    geometry = shape['geometry']
    return if geometry['type'] == 'Polygon'
    coordinates = geometry['coordinates']

    @device = Device.create(caps_id:                        caps_id,
                            name:                           properties['NOME'],
                            address:                        properties['ENDERECO'],
                            city:                           properties['CIDADE'],
                            uf:                             properties['UF'],
                            cep:                            properties['CEP'],
                            phone1:                         properties['FONE1'],
                            phone2:                         properties['FONE2'],
                            email:                          properties['EMAIL'],
                            website:                        properties['SITE'],
                            public_policy:                  properties['PUB_POL'],
                            operation_days:                 properties['FUNC'],
                            working_hours:                  properties['HORARIO'],
                            target_audience:                properties['PUB_ALVO'],
                            ad_area:                        properties['ABRANG'],
                            first_attendance_time:          properties['ATEND_1'],
                            first_attendance_documentation: properties['DOC_1'],
                            device_description:             properties['DESCR'],
                            latitude:                       coordinates[1],
                            longitude:                      coordinates[0])
  end
  # rubocop:enable Metrics/AbcSize, Metrics/MethodLength, Metrics/LineLength

  def destroy_device
    @device = Device.find(@request.device_id)
    @device.destroy
  end

  def refuse_automatically
    @refuse = DevicesRequest.all
    @refuse.each do |request|
      request.update(status: 0) if request.device_id == @request.device_id &&
                                   request.id != @request.id &&
                                   request.status == 2
    end
  end
end