module NasfsHelper

def create_nasf_from_file(shape)
    properties = shape['properties']
    geometry = shape['geometry']
    return if geometry['type'] == 'Polygon'
    coordinates = geometry['coordinates']

    @nasf = Nasf.create(nasf_type:                           properties['TIPONASF'],
						lotation:                          	 properties['LOTACAO'],
						ubs:                  		      	 properties['UBS'],
						team:                  		      	 properties['EQUIPE'],
						specialties:                  		 properties['ESPEC'],
						health_region:                  	 properties['REGIAO'],)
  end
end
 