# Contains functions that control administrator access on the user's views
module UsersHelper
  def admin?
    logged_in? && current_user.admin
  end

  def require_login
    return if logged_in?
    flash[:danger] = 'Você deve estar logado para realizar uma solicitação'
    redirect_to login_path
  end

  def require_admin
    return if admin?
    flash[:danger] = 'Você precisa ser administrador para realizar essa ação!'
    redirect_to root_path
  end
end
