class Assistance < ApplicationRecord
end
