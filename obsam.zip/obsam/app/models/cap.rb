class Cap < ApplicationRecord
end
