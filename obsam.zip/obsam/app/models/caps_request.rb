class CapsRequest < ApplicationRecord
  belongs_to :user
  validates  :description, presence: true, length: { minimum: 10 }
  validates  :name, presence: true
  validates  :modality, presence: true
end
