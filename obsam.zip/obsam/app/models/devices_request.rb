class DevicesRequest < ApplicationRecord
  belongs_to :user
  validates  :caps_id, presence: true
  validates  :device_description, presence: true, length: { minimum: 10 }
  validates  :description, presence: true, length: { minimum: 10 }
  validates  :name, presence: true
  validates  :public_policy, presence: true

  attr_accessor :other
end
