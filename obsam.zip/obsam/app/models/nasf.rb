class Nasf < ApplicationRecord
end
