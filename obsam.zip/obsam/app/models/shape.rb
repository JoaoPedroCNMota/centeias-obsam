class Shape < ApplicationRecord
  validates :cap_id, presence: true
  validates :geojson, presence: true
end
