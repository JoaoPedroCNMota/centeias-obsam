class Ub < ApplicationRecord
end
