Rails.application.routes.draw do
  resources :autofiles
  resources :nasfs
  resources :ubs
	root   'welcome#home'

  # Users
  resources :users
  get    '/signup',      to: 'users#new', as: 'user_new'
  post   '/signup',      to: 'users#create'
  get	   '/login',       to: 'sessions#new', as: 'session_new'

  get 'users/edit' => 'users#edit', :as => 'users_edit'
  patch 'users/update' => 'users#update', :as => 'users_update'


  # Sessions
  post   '/login',       to: 'sessions#create'
  delete '/logout',      to: 'sessions#destroy'

  # CapsRequests
  resources :caps_requests
  post '/accept', to: 'caps_requests#accept', as: 'caps_request_accept'
  post '/refuse', to: 'caps_requests#refuse', as: 'caps_request_refuse'
  get  '/destroy_caps', to: 'caps_requests#destroy_request', as: 'destroy_caps_request'
  post '/destroy_caps_request', to: 'caps_requests#destruction_request', as: 'caps_request_destruction'
  post '/update_caps_request', to: 'caps_requests#update_caps', as: 'caps_request_update'

  # Caps
  resources :caps

  # DevicesRequests
  resources :devices_requests
  post '/accept_device', to: 'devices_requests#accept', as: 'device_request_accept'
  post '/refuse_device', to: 'devices_requests#refuse', as: 'device_request_refuse'
  get  '/destroy_device', to: 'devices_requests#destroy_request', as: 'destroy_device_request'
  post '/destroy_device_request', to: 'devices_requests#destruction_request', as: 'device_request_destruction'
  post '/update_device_request', to: 'devices_requests#update_device', as: 'device_request_update'

  # Devices
  resources :devices

  #Shapes
  resources :shapes

  #Assistances
  resources :assistances
  #get 'creas', to: 'assistances#index'
end
