class CreateCaps < ActiveRecord::Migration[5.1]
  def change
    create_table :caps do |t|
      t.string  :unit
      t.string  :caps_description
      t.string  :name
      t.string  :address
      t.string  :ad_region
      t.string  :modality
      t.string  :phone
      t.string  :working_hours
      t.string  :coverage_area
      t.float   :latitude
      t.float   :longitude

      t.timestamps
    end
  end
end
