class CreateDevices < ActiveRecord::Migration[5.1]
  def change
    create_table :devices do |t|
      t.integer :caps_id, references: [:caps, :id]
      t.string  :name                           # nome
      t.string  :address                        # endereco
      t.string  :city                           # cidade
      t.string  :uf                             # uf
      t.string  :cep                            # cep
      t.string  :phone1                         # telefone 1
      t.string  :phone2                         # telefone 2
      t.string  :email                          # e-mail
      t.string  :website                        # site
      t.string  :public_policy                  # politica publica 
      t.string  :operation_days                 # dias de funcionamento
      t.string  :working_hours                  # horario
      t.string  :target_audience                # publico alvo
      t.string  :ad_area                        # area de abrangencia
      t.string  :first_attendance_time          # 1o atendimento nos seguintes dias e horarios
      t.string  :first_attendance_documentation # documentacao necessaria para o primeiro atendimento
      t.string  :device_description             # descricao do dispositivo
      t.float   :latitude
      t.float   :longitude


      t.timestamps
    end
  end
end
