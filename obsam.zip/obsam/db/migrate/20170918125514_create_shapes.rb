class CreateShapes < ActiveRecord::Migration[5.1]
  def change
    create_table :shapes do |t|
      t.belongs_to :cap
      t.jsonb :geojson

      t.timestamps
    end
  end
end
