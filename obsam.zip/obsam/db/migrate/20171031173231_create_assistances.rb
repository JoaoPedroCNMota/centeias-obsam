class CreateAssistances < ActiveRecord::Migration[5.1]
  def change
    create_table :assistances do |t|
      t.string   :name
      t.string   :address
      t.string   :phone
      t.float    :latitude
      t.float    :longitude
      t.integer  :assist_type
      t.jsonb    :geojson

      t.timestamps
    end
  end
end
