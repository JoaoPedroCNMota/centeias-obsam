class CreateUbs < ActiveRecord::Migration[5.1]
  def change
    create_table :ubs do |t|
      t.string :cnes
      t.string :name
      t.string :adress
      t.string :cep
      t.string :unity_type
      t.string :working_hours
      t.string :drugstore
      t.string :dental_care
      t.float :latitude
      t.float :longitude
      t.jsonb :geojson

      t.timestamps
    end
  end
end
