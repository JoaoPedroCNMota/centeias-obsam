class CreateNasfs < ActiveRecord::Migration[5.1]
  def change
    create_table :nasfs do |t|
      t.string :nasf_type
      t.string :lotation
      t.string :ubs
      t.string :team
      t.string :specialties
      t.string :health_region
      t.jsonb :geojson

      t.timestamps
    end
  end
end
