class AddFieldToUbs < ActiveRecord::Migration[5.1]
  def change
    add_column :ubs, :phone1, :string
    add_column :ubs, :health_region, :string
  end
end
