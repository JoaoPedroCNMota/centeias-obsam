# This file is auto-generated from the current state of the database. Instead
# of editing this file, please use the migrations feature of Active Record to
# incrementally modify your database, and then regenerate this schema definition.
#
# Note that this schema.rb definition is the authoritative source for your
# database schema. If you need to create the application database on another
# system, you should be using db:schema:load, not running all the migrations
# from scratch. The latter is a flawed and unsustainable approach (the more migrations
# you'll amass, the slower it'll run and the greater likelihood for issues).
#
# It's strongly recommended that you check this file into your version control system.

ActiveRecord::Schema.define(version: 20190227194744) do

  # These are extensions that must be enabled in order to support this database
  enable_extension "plpgsql"

  create_table "assistances", force: :cascade do |t|
    t.string "name"
    t.string "address"
    t.string "phone"
    t.float "latitude"
    t.float "longitude"
    t.integer "assist_type"
    t.jsonb "geojson"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
  end

  create_table "caps", force: :cascade do |t|
    t.string "unit"
    t.string "caps_description"
    t.string "name"
    t.string "address"
    t.string "ad_region"
    t.string "modality"
    t.string "phone"
    t.string "working_hours"
    t.string "coverage_area"
    t.float "latitude"
    t.float "longitude"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
  end

  create_table "caps_requests", force: :cascade do |t|
    t.bigint "user_id"
    t.integer "status", default: 2
    t.integer "request_type"
    t.text "description"
    t.integer "caps_id"
    t.string "unit"
    t.string "caps_description"
    t.string "name"
    t.string "address"
    t.string "ad_region"
    t.string "modality"
    t.string "phone"
    t.string "working_hours"
    t.string "coverage_area"
    t.float "latitude"
    t.float "longitude"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["user_id"], name: "index_caps_requests_on_user_id"
  end

  create_table "devices", force: :cascade do |t|
    t.integer "caps_id"
    t.string "name"
    t.string "address"
    t.string "city"
    t.string "uf"
    t.string "cep"
    t.string "phone1"
    t.string "phone2"
    t.string "email"
    t.string "website"
    t.string "public_policy"
    t.string "operation_days"
    t.string "working_hours"
    t.string "target_audience"
    t.string "ad_area"
    t.string "first_attendance_time"
    t.string "first_attendance_documentation"
    t.string "device_description"
    t.float "latitude"
    t.float "longitude"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
  end

  create_table "devices_requests", force: :cascade do |t|
    t.bigint "user_id"
    t.integer "status", default: 2
    t.integer "request_type"
    t.text "description"
    t.integer "caps_id"
    t.integer "device_id"
    t.string "name"
    t.string "address"
    t.string "city"
    t.string "uf"
    t.string "cep"
    t.string "phone1"
    t.string "phone2"
    t.string "email"
    t.string "website"
    t.string "public_policy"
    t.string "operation_days"
    t.string "working_hours"
    t.string "target_audience"
    t.string "ad_area"
    t.string "first_attendance_time"
    t.string "first_attendance_documentation"
    t.string "device_description"
    t.float "latitude"
    t.float "longitude"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["user_id"], name: "index_devices_requests_on_user_id"
  end

  create_table "nasfs", force: :cascade do |t|
    t.string "nasf_type"
    t.string "lotation"
    t.string "ubs"
    t.string "team"
    t.string "specialties"
    t.string "health_region"
    t.jsonb "geojson"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
  end

  create_table "shapes", force: :cascade do |t|
    t.bigint "cap_id"
    t.jsonb "geojson"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["cap_id"], name: "index_shapes_on_cap_id"
  end

  create_table "ubs", force: :cascade do |t|
    t.string "cnes"
    t.string "name"
    t.string "adress"
    t.string "cep"
    t.string "unity_type"
    t.string "working_hours"
    t.string "drugstore"
    t.string "dental_care"
    t.float "latitude"
    t.float "longitude"
    t.jsonb "geojson"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.string "phone1"
    t.string "health_region"
  end

  create_table "users", force: :cascade do |t|
    t.string "name"
    t.string "username"
    t.string "password_digest"
    t.boolean "admin", default: false
  end

end
