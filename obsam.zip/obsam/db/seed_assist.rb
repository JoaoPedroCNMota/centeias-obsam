creas = Assistance.create(name: 'Brasília',
                          address: 'Av. L2 Sul - Qd. 614\/615 - Lote 104',
                          phone: '3346-9332 e 3245-8129',
                          longitude: -15.836408456822724,
                          latitude: -47.915748095529374)

creas = Assistance.create(name: 'Ceilândia',
                          address: 'QNM 16 - AE - Módulo A - Ceilândia Norte',
                          phone: '3581-2260 e 3581-6005',
                          longitude: -15.806334224171485,
                          latitude: -48.109510189612976)

creas = Assistance.create(name: 'Estrutural',
                          address: 'SCIA, QD 15, Cj. 02, Lt. 18 - Cidade do Automóvel (Sede Provisória)',
                          phone: '2101-5885 e 2101-5886',
                          longitude: -15.78187202860877,
                          latitude:-47.998142063778914 )

creas = Assistance.create(name: 'Planaltina',
                          address: 'Qd. 06 - AE H - Setor Central',
                          phone: '3389-8996',
                          longitude: -15.623572880755145,
                          latitude: -47.65285083268467)

creas = Assistance.create(name: 'Sobradinho',
                          address: 'Qd. 06 - AE 03',
                          phone: '3387-8651 e 3387-2241',
                          longitude: -15.652569784252696,
                          latitude: -47.799460649049202)

creas = Assistance.create(name: 'Taguatinga',
                          address: 'AE 09, Setor D-Sul - Taguatinga Sul',
                          phone: '3563-3155 e 3352-3380',
                          longitude: -15.844023168163767,
                          latitude: -48.050745089385565)

creas = Assistance.create(name: 'Gama',
                          address: 'AE 11\/13 - Setor Central',
                          phone: '3556-3973 e 3484-1257',
                          longitude: -16.017431267676603,
                          latitude: -48.065110030833132)

creas = Assistance.create(name: 'Samambaia',
                          address: 'QN 419, Área Especial 1, Samambaia Norte',
                          phone: '98448-0351',
                          longitude: -15.880209631818351,
                          latitude: -48.120245206827356)