#require 'seed_assist'

user = User.create(name: 'Administrator',
   								 username: 'admin@obsam',
   								 password: 'obsam1',
   								 password_confirmation: 'obsam1',
   								 admin: true)
# Creating CAPS Requests
caps_request = CapsRequest.create(user_id: 1,
                                  description:'Adicionado através do seed',
                                  request_type: 1,
                                  status: 2,
                                  caps_id: nil,
                                  unit: 1,
                                  name: "CAPS ad II Sobradinho",
                                  address: "Área Residencial 17, Chácara 14",
                                  ad_region: "Sobradinho II",
                                  modality: "CAPS ad II",
                                  phone: "39013325 \/ 39013328 \/ 34852286",
                                  coverage_area: "Planaltina, Sobradinho I e II (+ Lago Oeste, Grande Colorado, Torto, Queima Lençol e Rota do Cavalo) e Fercal",
                                  latitude: -15.646743062218784,
                                  longitude: -47.816545916389522,
                                  caps_description: "O CAPSad -  é uma instituição da rede de atenção à saúde mental brasileira, parte integrante do SUS, aberto à comunidade. Atende gratuitamente usuários de álcool e outras drogas que queiram fazer tratamento e melhorar sua qualidade de vida.",
                                  working_hours: "2ª à 6ª, de 07:00 às 18:00 horas.")

caps_request = CapsRequest.create(user_id: 1,
                                  description:'Adicionado através do seed',
                                  request_type: 1,
                                  status: 2,
                                  caps_id: nil,
                                  unit: 2,
                                  name: "CAPS ad III Samambaia",
                                  address: "QS 107, Conj. 8, Lotes 3, 4 e 5 Samambaia-DF",
                                  ad_region: "Samamabaia sul",
                                  modality: "CAPS ad III",
                                  phone: "3459-2581",
                                  coverage_area: "Samambaia, Taguatinga, Recanto das Emas",
                                  latitude: -15.883478266427289,
                                  longitude: -48.099409576682966,
                                  caps_description: "Atende adultos ou crianças e adolescentes, considerando as normativas do Estatuto da Criança e do Adolescente, com necessidades de cuidados clínicos contínuos. Serviço com no máximo doze leitos leitos para observação e monitoramento, de funcionamento 24 horas, incluindo feriados e finais de semana; indicado para Municípios ou regiões com população acima de duzentos mil habitantes.",
                                  working_hours:"24h" )

caps_request = CapsRequest.create(user_id: 1,
                                  description:'Adicionado através do seed',
                                  request_type: 1,
                                  status: 2,
                                  caps_id: nil,
                                  unit: 3,
                                  name: "CAPS ad II Santa Maria",
                                  address: "Q. 312, Conj. H, Casa 12, Santa Maria Norte",
                                  ad_region: "Santa Maria e Gama",
                                  modality: "CAPS ad II",
                                  phone: "98239-3418",
                                  coverage_area: "Santa Maria e Gama",
                                  latitude: -16.012926875366809,
                                  longitude: -48.004604291658517,
                                  caps_description: "Atende pessoas com transtornos mentais graves e persistentes, podendo também atender pessoas com necessidades decorrentes do uso de crack, álcool e outras drogas, conforme a organização da rede de saúde local, indicado para Municípios com população acima de setenta mil habitantes",
                                  working_hours: "2ª a 6ª de 7h às 19h e ao sábado")

caps_request = CapsRequest.create(user_id: 1,
                                  description:'Adicionado através do seed',
                                  request_type: 1,
                                  status: 2,
                                  caps_id: nil,
                                  unit: 4,
                                  name: "CAPS ad II Guará",
                                  address: "QE 23, Área Especial S\/N, Subsolo do Centro de Saúde 02, Guará",
                                  ad_region: "Guará",
                                  modality: "CAPS ad II",
                                  phone: "3567-1967",
                                  coverage_area: "Guará, Estrutural, Águas Claras (+Areal), Vicente Pires, Park Way, S.I.A., Riacho Fundo I e II, Núcleo Bandeirante e Candangolândia",
                                  latitude: -15.832788458488208,
                                  longitude: -47.973254541316166,
                                  caps_description: "CAPS ad - Centro de Atenção Psicossocial álcool e drogas - é um dispositivo aberto do Sistema Único de Saúde, integra a Rede de Atenção Psicossocial. É constituído por equipe interdisciplinar, dentro de uma área territorial. Destinado ao acolhimento e acompanhamento de pessoas maiores de 16 anos com necessidades decorrentes do uso de álcool e outras drogas. Tem por objetivo trabalhar a integração social e familiar e promover a autonomia e a cidadania, através de um trabalho de reabilitação psicossocial. Possui acolhimento, práticas integrativas de saúde como dança sênior e automassagem, projeto terapêutico individual, oficinas e atividades terapêuticas, acompanhamento psiquiátrico e terapia comunitária.",
                                  working_hours: "Seg-sex 07h30-11h30 13h30-17h30")

caps_request = CapsRequest.create(user_id: 1,
                                  description:'Adicionado através do seed',
                                  request_type: 1,
                                  status: 2,
                                  caps_id: nil,
                                  unit: 5,
                                  name: "CAPS ad II Itapoã",
                                  address: "Anexo II, Complexo Administrativo do Itapoã, Q. 378, Conj. A, AE 4, Lago Oeste",
                                  ad_region: "Itapoã, Paranoá",
                                  modality: "CAPS ad II",
                                  phone: "3369-9438",
                                  coverage_area: "Itapoã, Paranoá",
                                  latitude: -15.744641458292577,
                                  longitude: -47.761355749951093,
                                  caps_description: "CAPS ad - Centro de Atenção Psicossocial álcool e droga - é dispositivo aberto do Sistema Único de Saúde, integra a Rede de Atenção Psicossocial. É constituído por equipe interdisciplinar, dentro de uma área territorial. Destinado ao acolhimento e acompanhamento de pessoas maiores de 16 anos com necessidades decorrentes do uso de álcool e outras drogas. Tem por objetivo trabalhar a integração social e familiar e promover a autonomia e a cidadania, através de um trabalho de reabilitação psicossocial.",
                                  working_hours: "Seg-sex 07-18h ")

caps_request = CapsRequest.create(user_id: 1,
                                  description:'Adicionado através do seed',
                                  request_type: 1,
                                  status: 2,
                                  caps_id: nil,
                                  unit: 6,
                                  name: "CAPS ad III Ceilândia",
                                  address: "QNN 01, Conj. A, Lote 45\/47, Av. Leste (Ao Lado da Beth & Lili)",
                                  ad_region: "Ceilândia, Brazlândia",
                                  modality: "CAPS ad III",
                                  phone: "3372-1117",
                                  coverage_area: "Ceilândia, Brazlândia",
                                  latitude: -15.8214545,
                                  longitude: -48.1069964,
                                  caps_description: "O CAPS-AD é um serviço especializado em saúde mental que atende pessoas maiores de 16 anos com problemas  decorrentes do uso ou abuso de álcool e outras drogas e que tem como princípio a reinserção social. Realiza ações de assistência (medicação, terapias, oficinas terapêuticas, atenção familiar), de prevenção e capacitação de profissionais para lidar com os dependentes.",
                                  working_hours: "24h")

caps_request = CapsRequest.create(user_id: 1,
                                  description:'Adicionado através do seed',
                                  request_type: 1,
                                  status: 2,
                                  caps_id: nil,
                                  unit: 7,
                                  name: "CAPS ad III Candango",
                                  address: "SCS, Q. 5, Bloco C, Loja 73, Asa Sul",
                                  ad_region: "Setor Comercial Sul",
                                  modality: "CAPS ad III",
                                  phone: "3226-4532",
                                  coverage_area: "Brasília (Asa Sul e Asa Norte), Cruzeiro, Octogonal, Sudoeste, Lago Sul, Lago Norte, Varjão, Vila Planalto, São Sebastião, SAAN, Jardim Botânico",
                                  latitude: -15.797208500097817,
                                  longitude: -47.889639583903922,
                                  caps_description: "CAPSIII– As instalações do CAPS Candango funcionam em uma área de aproximadamente 1.300 metros quadrados. O local tem sete consultórios, sala de acolhimento, sala de convivência, refeitório, duas salas para atividades em grupo, sala de reunião, enfermaria com 12 leitos, banheiros adaptados para pessoas com necessidades especiais e elevador.",
                                  working_hours: "24h")

caps_request = CapsRequest.create(user_id: 1,
                                  description:'Adicionado através do seed',
                                  request_type: 1,
                                  status: 2,
                                  caps_id: nil,
                                  unit: 8,
                                  name: "CAPSi II Taguatinga",
                                  address: "QNF, Área Especial 24, Taguatinga",
                                  ad_region: "Taguatinga",
                                  modality: "CAPSi II",
                                  phone: "98380-0611",
                                  coverage_area: "Taguatinga, Ceilândia, Brazlândia, Vicente Pires, Águas Claras",
                                  latitude: -15.819209129048476,
                                  longitude: -48.070453537487772,
                                  caps_description: "CAPS infanto juvenil. A unidade acompanha crianças e adolescentes de zero a 18 anos, com transtorno mental grave e persistente, bem como sofrimento psíquico de grau elevado.Nesse processo características como capacidade de organização, entendimento, estado psíquico/emocional e apoio familiar são levadas em conta no tratamento dos pacientes.",
                                  working_hours: "8h às 17h")

caps_request = CapsRequest.create(user_id: 1,
                                  description:'Adicionado através do seed',
                                  request_type: 1,
                                  status: 2,
                                  caps_id: nil,
                                  unit: 9,
                                  name: "CAPSi II Recanto das Emas",
                                  address: "Quadra 307, A\/E 1 (no Centro de Saúde 1 do Recanto das Emas, em frente à Clínica da Família)",
                                  ad_region: "Recanto das Emas",
                                  modality: "CAPSi II",
                                  phone: "3332-4621 \/ 98172-7553",
                                  coverage_area: "Samambaia, Recanto das Emas, Gama, Santa Maria, Riacho Fundo I e II",
                                  latitude: -15.919357264317465,
                                  longitude: -48.101606539951092,
                                  caps_description: "CAPS infanto juvenil.A unidade acompanha crianças e adolescentes de zero a 18 anos, com transtorno mental grave e persistente, bem como sofrimento psíquico de grau elevado. Por mês, são realizados cerca de 450 atendimentos.",
                                  working_hours: "8h às 17h")

caps_request = CapsRequest.create(user_id: 1,
                                  description:'Adicionado através do seed',
                                  request_type: 1,
                                  status: 2,
                                  caps_id: nil,
                                  unit: 10,
                                  name: "CAPSi II Sobradinho",
                                  address: "Quadra 4, Área Especial, Lotes 1\/2",
                                  ad_region: "Sobradinho I",
                                  modality: "CAPSi II",
                                  phone: "99241-2878",
                                  coverage_area: "Sobradinho I e II, Fercal (+Condomínios), Planaltina, Paranoá, Jardim Botânico, Itapoã, São Sebastião",
                                  latitude: -15.654108541707423,
                                  longitude: -47.795558832974677,
                                  caps_description: "Atende crianças e adolescentes com transtornos mentais graves e persistentes e os que fazem uso de crack, álcool e outras drogas. Serviço aberto e de caráter comunitário indicado para municípios ou regiões com população acima de cento e cinquenta mil habitantes",
                                  working_hours: "SEG-SEX 8:00 AS 18:00")

caps_request = CapsRequest.create(user_id: 1,
                                  description:'Adicionado através do seed',
                                  request_type: 1,
                                  status: 2,
                                  caps_id: nil,
                                  unit: 11,
                                  name: "CAPS II Transtorno Brasília",
                                  address: "SCRLN 904, Centro de Saúde n. 5, Asa Norte",
                                  ad_region: "Asa Norte",
                                  modality: "CAPS II Transtorno",
                                  phone: "3347-9330",
                                  coverage_area: "Sudoeste, Octogonal, Cruzeiro, Brasília (Asa Sul e Asa Norte), Lago Norte, Varjão, Cruzeiro, Sobradinho I e II",
                                  latitude: -15.773354458096945,
                                  longitude: -47.892615500293445,
                                  caps_description: "Atende pessoas com transtornos mentais graves e persistentes, podendo também atender pessoas com necessidades decorrentes do uso de crack, álcool e outras drogas, conforme a organização da rede de saúde local, indicado para Municípios com população acima de setenta mil habitantes",
                                  working_hours: "SEG-SEX 8:00 AS 18:00")

caps_request = CapsRequest.create(user_id: 1,
                                  description:'Adicionado através do seed',
                                  request_type: 1,
                                  status: 2,
                                  caps_id: nil,
                                  unit: 12,
                                  name: "CAPS II Transtorno Taguatinga",
                                  address: "QSA 09, Casa 09",
                                  ad_region: "Taguatinga",
                                  modality: "CAPS II Transtorno",
                                  phone: "98296-1661",
                                  coverage_area: "Taguatinga, Vicente Pires, Guará, Estrutural, Águas Claras, Ceilândia, Brazlândia",
                                  latitude: -15.834402668883824,
                                  longitude: -48.05304530168749,
                                  caps_description: "Atende pessoas com transtornos mentais graves e persistentes, podendo também atender pessoas com necessidades decorrentes do uso de crack, álcool e outras drogas, conforme a organização da rede de saúde local, indicado para Municípios com população acima de setenta mil habitantes",
                                  working_hours: "SEG-SEX 8:00 AS 17:00")

caps_request = CapsRequest.create(user_id: 1,
                                  description:'Adicionado através do seed',
                                  request_type: 1,
                                  status: 2,
                                  caps_id: nil,
                                  unit: 13,
                                  name: "CAPS II Transtorno Paranoá",
                                  address: "Q. 02, Conj. K, Área Especial 1, Setor Hospitalar do Paranoá",
                                  ad_region: "Paranoá",
                                  modality: "CAPS II Transtorno",
                                  phone: "3369-9933",
                                  coverage_area: "Paranoá, Itapoã (+Condomínio Del Lago, Fazendinha e Zona Rural), São Sebastião, Lago Sul",
                                  latitude: -15.780968500097815,
                                  longitude: -47.782705687536676,
                                  caps_description: "Atende prioritariamente pessoas em intenso sofrimento psíquico decorrente de transtornos mentais graves e persistentes, incluindo aqueles relacionados ao uso de substâncias psicoativas, e outras situações clínicas que impossibilitem estabelecer laços sociais e realizar projetos de vida.",
                                  working_hours: "Segunda a Sexta - 7h às 18h")

caps_request = CapsRequest.create(user_id: 1,
                                  description:'Adicionado através do seed',
                                  request_type: 1,
                                  status: 2,
                                  caps_id: nil,
                                  unit: 14,
                                  name: "CAPS II Transtorno Planaltina",
                                  address: "Via W\/L nº 4 Setor Hospitalar Oeste, Área Especial Planaltina DF",
                                  ad_region: "Planaltina",
                                  modality: "CAPS II Transtorno",
                                  phone: "3388-9650",
                                  coverage_area: "Planaltina",
                                  latitude: -15.624607031402837,
                                  longitude: -47.651151427085367,
                                  caps_description: " Atende prioritariamente pessoas em intenso sofrimento psíquico decorrente de transtornos mentais graves e persistentes, incluindo aqueles relacionados ao uso de substâncias psicoativas, e outras situações clínicas que impossibilitem estabelecer laços sociais e realizar projetos de vida.",
                                  working_hours: "Segunda a Sexta - 7h às 18h")

caps_request = CapsRequest.create(user_id: 1,
                                  description:'Adicionado através do seed',
                                  request_type: 1,
                                  status: 2,
                                  caps_id: nil,
                                  unit: 15,
                                  name: "CAPS III Transtorno Samambaia",
                                  address: "Quadra 302 Conjunto 5 Lote 1 - Centro Urbano - Samambaia",
                                  ad_region: "Samambaia",
                                  modality: "CAPS III Transtorno",
                                  phone: "99172-2595",
                                  coverage_area: "Recanto das Emas, Samambaia e Ceilândia (QNM e QNN)",
                                  latitude: -15.879968821000437,
                                  longitude: -48.081989647487774,
                                  caps_description: "Atende prioritariamente pessoas em intenso sofrimento psíquico decorrente de transtornos mentais graves e persistentes, incluindo aqueles relacionados ao uso de substâncias psicoativas, e outras situações clínicas que impossibilitem estabelecer laços sociais e realizar projetos de vida. Proporciona serviços de atenção contínua, com funcionamento vinte e quatro horas, incluindo feriados e finais de semana, ofertando retaguarda clínica e acolhimento noturno a outros serviços de saúde mental, inclusive CAPS AD.",
                                  working_hours: "Segunda a Sexta - 8h às 18h")

caps_request = CapsRequest.create(user_id: 1,
                                  description:'Adicionado através do seed',
                                  request_type: 1,
                                  status: 2,
                                  caps_id: nil,
                                  unit: 16,
                                  name: "CAPS II Transtorno ISM",
                                  address: "Granja do Riacho Fundo, EPNB Km 04, AE, Riacho Fundo",
                                  ad_region: "Riacho Fundo",
                                  modality: "CAPS II Transtorno",
                                  phone: "3399-3600 \/ 3399-3910",
                                  coverage_area: "Riacho Fundo I e II, Recanto das Emas, Núcleo Bandeirante, Candangolândia, Gama, Santa Maria",
                                  latitude: -15.892250416096077,
                                  longitude: -48.034605708341488,
                                  caps_description: "Institituto de Saúde Mental, atende adultos acima de 18 anos com transtornos mentais graves e persistentes. Acolhimento, matriciamento, atividades e oficinas terapêuticas, centro de convivência, acompanhamento psiquiátrico, visita domiciliar e programa vida em casa, terapia comunitária, programa de ressocialização de pacientes em conflito com a Lei, programa de geração de renda e atendimento à pessoas vítimas de violência",
                                  working_hours: "Segunda a sexta 7h às 19h")

caps_request = CapsRequest.create(user_id: 1,
                                  description:'Adicionado através do seed',
                                  request_type: 1,
                                  status: 2,
                                  caps_id: nil,
                                  unit: 17,
                                  name: "CAPS i II Asa Norte",
                                  address: "SMHN, Qd. 03, Conj. 1, Bloco A Ed. COMPP, Asa Norte",
                                  ad_region: "Asa Norte",
                                  modality: "CAPSi II",
                                  phone: "3325-4995",
                                  coverage_area: "Todas as regiões do Distrito Federal",
                                  latitude: -15.784597187438864,
                                  longitude: -47.886920187243227,
                                  caps_description: "O Centro de Orientação Médico Psicopedagógica - COMPP/SES, Órgão da Secretaria de Estado de Saúde do Distrito Federal, presta atendimento multi e interdisciplinar em Saúde Mental às crianças e adolescentes do DF e Entorno. Atende desde os casos mais leves de sofrimento psíquico, até os transtornos mentais mais graves como: Autismo, Psicoses e Neuroses. Possui ainda um acolhimento humanizado, diário, com classificação de risco, realizado por profissionais capacitados e com o objetivo de otimizar o processo de trabalho na Unidade e de avaliar a gravidade e a urgência de cada caso para maior resolutividade e agilidade no atendimento.",
                                  working_hours: "Todas às 2ª feiras, 4ª feiras e 6ª feiras às 7h da manhã.")

caps_request = CapsRequest.create(user_id: 1,
                                  description:'Adicionado através do seed',
                                  request_type: 1,
                                  status: 2,
                                  caps_id: nil,
                                  unit: 18,
                                  name: "Adolescentro",
                                  address: "SGAS 605, Lt 32\/33",
                                  ad_region: "Asa Sul",
                                  modality: "CAPSi",
                                  phone: "3443-1855",
                                  coverage_area: "Todas as regiões do Distrito Federal",
                                  latitude: -15.816574,
                                  longitude: -47.888813,
                                  caps_description: "O Centro de Atendimento ao Adolescente atende jovens de 10 a 18 anos com transtornos mentais, dificuldade de aprendizado e que tenham sido vítimas de violência sexual. O local pertence à Secretaria de Saúde do Distrito Federal e atende adolescentes de todo o DF e inclusive da RIDE – a Rede Integrada de Desenvolvimento Do Entorno. O Centro possui uma equipe  multidisciplinar que inclui pediatras, psiquiatras, neurologistas, assistente social, psicólogo, terapeuta ocupacional. dentista, infermeiros e nutricionista que atendem diariamente o adolescente na sua integralidade individualmente ou em grupos, além de suas famílias.",
                                  working_hours: "Segunda-feira a sexta feira, de 7 às 12 horas e de 13 às 18 horas.")


#######################################################################


creas = Assistance.create(name: "Brasília",
                          address: "Av. L2 Sul - Qd. 614\/615 - Lote 104",
                          phone: "3346-9332 e 3245-8129",
                          latitude: -15.836408456822724,
                          longitude: -47.915748095529374,
                          assist_type: 1)

creas = Assistance.create(name: "Ceilândia",
                          address: "QNM 16 - AE - Módulo A - Ceilândia Norte",
                          phone: "3581-2260 e 3581-6005",
                          latitude: -15.806334224171485,
                          longitude: -48.109510189612976,
                          assist_type: 1)

creas = Assistance.create(name: "Estrutural",
                          address: "SCIA, QD 15, Cj. 02, Lt. 18 - Cidade do Automóvel (Sede Provisória)",
                          phone: "2101-5885 e 2101-5886",
                          latitude: -15.78187202860877,
                          longitude:-47.998142063778914,
                          assist_type: 1)

creas = Assistance.create(name: "Planaltina",
                          address: "Qd. 06 - AE H - Setor Central",
                          phone: "3389-8996",
                          latitude: -15.623572880755145,
                          longitude: -47.65285083268467,
                          assist_type: 1)

creas = Assistance.create(name: "Sobradinho",
                          address: "Qd. 06 - AE 03",
                          phone: "3387-8651 e 3387-2241",
                          latitude: -15.652569784252696,
                          longitude: -47.799460649049202,
                          assist_type: 1)

creas = Assistance.create(name: "Taguatinga",
                          address: "AE 09, Setor D-Sul - Taguatinga Sul",
                          phone: "3563-3155 e 3352-3380",
                          latitude: -15.844023168163767,
                          longitude: -48.050745089385565,
                          assist_type: 1)

creas = Assistance.create(name: "Gama",
                          address: "AE 11\/13 - Setor Central",
                          phone: "3556-3973 e 3484-1257",
                          latitude: -16.017431267676603,
                          longitude: -48.065110030833132,
                          assist_type: 1)

creas = Assistance.create(name: "Samambaia",
                          address: "QN 419, Área Especial 1, Samambaia Norte",
                          phone: "98448-0351",
                          latitude: -15.880209631818351,
                          longitude: -48.120245206827356,
                          assist_type: 1)


#######################################################################

cras = Assistance.create(name: "Brasília",
                         address: "L2 Sul, SGAS 614\/615, Lote 104 B",
                         phone: "3346-6769 \/3346-3306 \/ 3346-1411",
                         latitude: -15.836411816170793,
                         longitude: -47.915749359733198,
                         assist_type: 2)

cras = Assistance.create(name: "Brazlândia Veredas",
                         address: "Quadra 35\/36, Área Especial 2, Vila São José, Brazlandia - Ponto de Referência: em frente ao Restaurante Comunitário",
                         phone: "3391-1057 \/ 3391-2677 \/ 3391-5626",
                         latitude: -15.682520840298681,
                         longitude: -48.197467779245628,
                         assist_type: 2)

cras = Assistance.create(name: "Candangolândia",
                         address: "QR 2, Área Especial, Candangolândia - Ponto de Referência: próximo a Feira da Candangolândia",
                         phone: "3301-7735 \/ 3301-8402 \/ 3301-3317",
                         latitude: -15.853042114103996,
                         longitude: -47.950661260153424,
                         assist_type: 2)

cras = Assistance.create(name: "Ceilândia Sul",
                         address: "QNM 15, A\/E Módulo A, Ceilandia -  Ponto de Referência: na Avenida da Admnistração",
                         phone: "3372-9841 \/ 3373-7961",
                         latitude: -15.827479696271919,
                         longitude: -48.097941434362873,
                         assist_type: 2)

cras = Assistance.create(name: "Ceilândia Norte",
                         address: "QNN 15, A\/E, Ceilandia - Ponto de Referência: ao lado do Centro de Ensino n° 7",
                         phone: "3274-3104 \/ 3274-3104",
                         latitude: -15.807736626440827,
                         longitude: -48.120504145105912,
                         assist_type: 2)

cras = Assistance.create(name: "Ceilândia P Sul",
                         address: "EQNP 12\/16, Lote C, AE P Sul, Ceilandia - Ponto de Referência: atrás da Madeireira Diacuy",
                         phone: "3376-7318 \/ 3376-2414 \/ 3378-1754",
                         latitude: -15.841812405620461,
                         longitude: -48.116509188526692,
                         assist_type: 2)

cras = Assistance.create(name: "Estrutural",
                         address: "Área Especial 9, Setor Central, Centro Comunitário",
                         phone: "3465-7558 \/ 3465-7556",
                         latitude: -15.781848972800603,
                         longitude: -47.998056352987476,
                         assist_type: 2)

cras = Assistance.create(name: "Fercal",
                         address: "DF-150, KM 12, Quadra 3, Área Especial, Engenho Velho, Fercal - Ponto de Referência: antigo Posto Policial",
                         phone: "3485-3824 \/ 3483-2588 \/ 3483-2571",
                         latitude: -15.601238409632819,
                         longitude: -47.870228909346892,
                         assist_type: 2)

cras = Assistance.create(name: "Gama",
                         address: "AE 11\/13, Setor Central, Gama - Ponto de Referência: ao lado da 14ª DP",
                         phone: "3384-4810 \/ 3384-1157 \/ 3384-8765",
                         latitude: -16.017424828235598,
                         longitude: -48.065098647022268,
                         assist_type: 2)

cras = Assistance.create(name: "Guará",
                         address: "EQ 15\/26, Área Comunal 1, Guará - Ponto de Referência: ao lado da 4ª DP",
                         phone: "3381-6963 \/ 3568-4059 \/ 3381-8212",
                         latitude: -15.831399276311918,
                         longitude: -47.980577371056945,
                         assist_type: 2)

cras = Assistance.create(name: "Itapoã",
                         address: "Qd 61, AE 3, Del Lago, Itapoã - Ponto de Referência: ao lado do Restaurante Comunitário",
                         phone: "3467-6001",
                         latitude: -15.744773486531953,
                         longitude: -47.770194470754852,
                         assist_type: 2)

cras = Assistance.create(name: "Núcleo Bandeirante",
                         address: "Av. Central A\/E, Lote E, Núcleo Bandeirante - Ponto de Referência: atrás do Colégio La Salle ou ao lado da 11ª DP",
                         phone: "3552-3421 \/ 3386-2514 \/ 3352-0747 \/ 3552-3567 \/ 3386-7564",
                         latitude: -15.869838519595893,
                         longitude: -47.966650857503126,
                         assist_type: 2)

cras = Assistance.create(name: "Paranoá",
                         address: "Quadra 3, A\/E 7, Paranoá - Ponto de Referência: atrás do Fórum",
                         phone: "3408-1863 \/ 3369-5262 \/ 3369-1516 \/ 3369-7903",
                         latitude: -15.779677011781274,
                         longitude: -47.784208923604382,
                         assist_type: 2)

cras = Assistance.create(name: "Planaltina",
                         address: "A\/E , Conj. H, Lt 6, Sede, Planaltina - Ponto de Referência: ao lado do Corpo de Bombeiros Militar",
                         phone: "3389-3845 \/ 3389-0437 \/ 3389-2862 \/ 3389-1664",
                         latitude: -15.622893810181415,
                         longitude: -47.652741072291342,
                         assist_type: 2)

cras = Assistance.create(name: "Planaltina Arapoanga",
                         address: "Quadra 18, Conj. H, AE 1, Vila Buritis IV, Planaltina",
                         phone: "3488-7141 \/ 3489-0754 \/ 3388-7295",
                         latitude: -15.617773788961083,
                         longitude: -47.641092605256532,
                         assist_type: 2)

cras = Assistance.create(name: "Recanto das Emas",
                         address: "Qd 602, Área Especial, Lt 1, Avenida Buritis, Recanto das Emas -  Ponto de Referência: ao lado do mercado Euro",
                         phone: "3332-1482",
                         latitude: -15.918374031551275,
                         longitude: -48.055188978000579,
                         assist_type: 2)

cras = Assistance.create(name: "Riacho Fundo II",
                         address: "QC 4, AE, Riacho Fundo II - Ponto de Referência: ao lado da Escola Classe n° 1",
                         phone: "3333-5223",
                         latitude: -15.914652663892216,
                         longitude: -48.046327349124546,
                         assist_type: 2)

cras = Assistance.create(name: "Riacho Fundo I",
                         address: "QS 12, A\/E, Lt F, Riacho Fundo I - Ponto de Referência: próximo ao posto policial da Colônia Agrícola Sucupira",
                         phone: "3399-3243 \/ 3404-6413 \/ 3399-4252 \/ 3399-3880",
                         latitude: -15.888536088910696,
                         longitude: -48.01550811561215,
                         assist_type: 2)

cras = Assistance.create(name: "Samambaia Sul",
                         address: "QN 317, AE 2, Samambaia Sul - Ponto de Referência: próximo a vila olímpica",
                         phone: "3357-3406 \/ 3358-7078",
                         latitude: -15.891334791895085,
                         longitude: -48.111955189281169,
                         assist_type: 2)

cras = Assistance.create(name: "Samambaia Expansão",
                         address: "Expansão da Samambaia, QR 833, Conj. 8, Lt 1, Samambaia Norte - Ponto de Referência: ao lado do mercado \"Nosso Mercado\"",
                         phone: "3459-3708 \/ 3459-3640 \/ 3459-3702",
                         latitude: -15.88959903770002,
                         longitude: -48.147599219235239,
                         assist_type: 2)

cras = Assistance.create(name: "Santa Maria",
                         address: "EQ 209\/309, Santa Maria Sul - Ponto de Referência: ao lado do Conselho Tutelar da Sul",
                         phone: "3394-1757",
                         latitude: -16.023724609951458,
                         longitude: -48.021323973958431,
                         assist_type: 2)

cras = Assistance.create(name: "São Sebastião",
                         address: "AE Qd 201, Res. Oeste, São Sebastião - Ponto de Referência: em frente ao Restaurante Comunitário",
                         phone: "3339-1512 \/ 3339 – 4028 \/ 3339-2102",
                         latitude: -15.905171272360294,
                         longitude: -47.775099529252913,
                         assist_type: 2)

cras = Assistance.create(name: "Sobradinho",
                         address: "Qd 6, AE 3, Lotes 6\/7, Sobradinho - Ponto de Referência: próximo ao Centro de Ensino Médio 01, antigo GINÁSIO",
                         phone: "3487-1780 \/ 3591-2203 \/ 3487-5463 \/ 3591-1837 \/ 3487-5463",
                         latitude: -15.652539821820175,
                         longitude: -47.799582945884424,
                         assist_type: 2)

cras = Assistance.create(name: "Sobradinho II",
 address: "AR 13, AE 5 (COER), Sobradinho II - Ponto de Referência: ao lado do COER",
                         phone: "3485-6621 \/ 3485-7198",
                         latitude: -15.642196485603547,
                         longitude: -47.819984862502814,
                         assist_type: 2)

cras = Assistance.create(name: "Taguatinga",
                         address: "QNG 27, A\/E 4, Tagua Norte, Taguatinga - Ponto de Referência: próximo ao Taguacenter",
                         phone: "3354-7715 \/ 3354-4419 \/ 3354-7929",
                         latitude: -15.80140569507668,
                         longitude: -48.06648847957586,
                         assist_type: 2)

cras = Assistance.create(name: "Taguatinga Areal",
                         address: "QS 9, Lote 1 a 7, Areal, Águas Claras, Universidade Católica de Brasília",
                         phone: "3356-3796",
                         latitude: -15.870101639552386,
                         longitude: -48.024707543052777,
                         assist_type: 2)

cras = Assistance.create(name: "Varjão",
                         address: "Quadra 7, Conj. D, Lote 1 A, Varjão - Ponto de Referência: ao lado da Escola Classe Varjão, próximo ao Posto da PM",
                         phone: "3468-8090 \/ 3468-8527 \/ 3468-1862",
                         latitude: -15.709047100729935,
                         longitude: -47.878710165872555,
                         assist_type: 2)


#######################################################################################

cons_tute = Assistance.create(name: "Conselho Tutelar de Brasília II (Norte)",
                              address: "EPN 513 Bloco D, Ed. Imperador, 1° Andar, Sala 131",
                              phone: "(61) 3447-4222 \/ 3347-0887",
                              latitude: -15.748060362467793,
                              longitude: -47.895633079024542,
                              assist_type: 3)

cons_tute = Assistance.create(name: "Conselho Tutelar de Águas Claras",
                              address: "Rua Manacá - LT. 02-BL. 01-Lojas 12\/14- Águas Claras",
                              phone: "(61) 3567-5953 \/ 3382-1484 \/ 3568-7273",
                              latitude: -15.835427794892919,
                              longitude: -48.008674886768418,
                              assist_type: 3)

cons_tute = Assistance.create(name: "Conselho Tutelar de Brazlândia",
                              address: "Quadra 24 Lote 06\/07 Setor Tradicional Brazlândia",
                              phone: "(61) 3479-1104",
                              latitude: -15.678342810085567,
                              longitude: -48.200861979246604,
                              assist_type: 3)

cons_tute = Assistance.create(name: "Conselho Tutelar da Candangolândia",
                              address: "QROA Conjunto D Casa 03 - Candangolândia",
                              phone: "(61) 3301-5091 \/ 3301-5065",
                              latitude: -15.853409777296264,
                              longitude: -47.947807087072711,
                              assist_type: 3)

cons_tute = Assistance.create(name: "Conselho Tutelar de Ceilândia I (Norte)",
                              address: "EQNN 5\/7 NR. 2 Galpão – Mod “C” Ceilândia Norte",
                              phone: "(61) 3471-1044 \/ 3471-1045",
                              latitude: -15.808642543916385,
                              longitude: -48.118196069261565,
                              assist_type: 3)

cons_tute = Assistance.create(name: "Conselho Tutelar de Ceilândia II (Sul)",
                              address: "QNM 03, Conjunto P, Lote 08 – Ceilândia Sul",
                              phone: "(61) 3372-0254 \/ 3471-1056",
                              latitude: -15.822953506979687,
                              longitude: -48.118987398644599,
                              assist_type: 3)

cons_tute = Assistance.create(name: "Conselho Tutelar de Ceilândia III",
                              address: "QNN 13 AE Mód. B Sala 01 Centro Cultural",
                              phone: "(61) 3373-2543 \/ 3373-2498",
                              latitude: -15.811309580318149,
                              longitude: -48.114899017201978,
                              assist_type: 3)

cons_tute = Assistance.create(name: "Conselho Tutelar do Cruzeiro",
                              address: "SRES Lote 03 AE Especial C Setor Escolar Cruzeiro Velho",
                              phone: "(61) 3234-7563 \/ 3234-5469",
                              latitude: -15.783648423245291,
                              longitude: -47.936488285024794,
                              assist_type: 3)

cons_tute = Assistance.create(name: "Conselho Tutelar da Estrutural",
                              address: "Setor Central Área Especial 19 ao lado do TRE",
                              phone: "(61) 3465-5161 \/ 3465-6909",
                              latitude: -15.781922469607251,
                              longitude: -47.998742919421836,
                              assist_type: 3)

cons_tute = Assistance.create(name: "Conselho Tutelar da Fercal",
                              address: "DF 150, Km 12, Quadra 11 Casa 14, Engenho Velho – Fercal",
                              phone: "(61) 3485-4923 \/ 3485-6283",
                              latitude: -15.596538678735225,
                              longitude: -47.874065064694143,
                              assist_type: 3)

cons_tute = Assistance.create(name: "Conselho Tutelar do Gama I",
                              address: "EQ 12\/13 Área Especial – Praça Central Setor - Oeste (antigo Castelinho)",
                              phone: "(61) 3484-1402 \/ 3484-7458",
                              latitude: -16.008505230810638,
                              longitude: -48.074004614682195,
                              assist_type: 3)

cons_tute = Assistance.create(name: "Conselho Tutelar do Gama II",
                              address: "Área Especial QD. 05, próximo ao 9º Batalhão da PM, Setor Sul",
                              phone: "(61) 3484-7859 \/ 3484-7946",
                              latitude: -16.033119787566132,
                              longitude: -48.057565010191333,
                              assist_type: 3)

cons_tute = Assistance.create(name: "Conselho Tutelar do Guará",
                              address: "QE 26 Conjunto K Casa 02",
                              phone: "(61) 3381-9652 \/ 3568-3829",
                              latitude: -15.832848630324404,
                              longitude: -47.984120632293269,
                              assist_type: 3)

cons_tute = Assistance.create(name: "Conselho Tutelar do Itapoã",
                              address: "Quadra 01 Conjunto A Lote 20 Itapoã I",
                              phone: "(61) - 3467-1123 \/ 3467-1177",
                              latitude: -15.75474229439156,
                              longitude: -47.778393873029927,
                              assist_type: 3)

cons_tute = Assistance.create(name: "Conselho Tutelar do Jardim Botânico",
                              address: "Condomínio Quintas do Sol QD 02 Casa 44 Jardim Botânico",
                              phone: "(61) 3339-1817 \/ 3335-6150 \/ 3335-3803",
                              latitude: -15.872443797391799,
                              longitude: -47.80070394240461,
                              assist_type: 3)

cons_tute = Assistance.create(name: "Conselho Tutelar do Lago Norte",
                              address: "SHIN-CA05 Bloco I Sala 4 e 5 Ed.Sant Regis – Lago Norte",
                              phone: "(61) 3468-1789 \/ 3468-8529 \/ 3568-5739",
                              latitude: -15.715888935614215,
                              longitude: -47.884806870489356,
                              assist_type: 3)

cons_tute = Assistance.create(name: "Conselho Tutelar do Lago Sul",
                              address: "SHIS QI 11 Área Especial 01",
                              phone: "(61) 3248-2120 \/ 3248-7170",
                              latitude: -15.840555681839644,
                              longitude: -47.869544402597363,
                              assist_type: 3)

cons_tute = Assistance.create(name: "Conselho Tutelar do Núcleo Bandeirante",
                              address: "3º avenida bloco 910 casa 01",
                              phone: "(61) 3386-6888 \/ 3386-0998 \/ 3386-1550",
                              latitude: -15.87143185956443,
                              longitude: -47.968937941017927,
                              assist_type: 3)

cons_tute = Assistance.create(name: "Conselho Tutelar do Paranoá",
                              address: "Quadra 21 Área Especial – Ao lado do Centro de Saúde",
                              phone: "(61) 3369-7850 \/ 3369-5686 \/ 3369-4148",
                              latitude: -15.769882648369347,
                              longitude: -47.780012436576769,
                              assist_type: 3)

cons_tute = Assistance.create(name: "Conselho Tutelar do Park Way",
                              address: "Quadra 08 Lote 05 Núcleo Rural Vargem Bonita",
                              phone: "(61) 3380-2090",
                              latitude: -15.934097305955909,
                              longitude: -47.941355895275699,
                              assist_type: 3)

cons_tute = Assistance.create(name: "Conselho Tutelar de Planaltina I",
                              address: "Área Especial Modulo “H” N.º 6 Bloco F – CREAS, - Sala 11, Planaltina-DF",
                              phone: "(61) 3388-4632 \/ 3388-4534 \/ 3389-1974 \/ 3389-1740",
                              latitude: -15.623596889977357,
                              longitude: -47.652799214295968,
                              assist_type: 3)

cons_tute = Assistance.create(name: "Conselho Tutelar de Planaltina II",
                              address: "Avenida WL 02 Setor Administrativo",
                              phone: "(61) 3388-4623",
                              latitude: -15.616782713889165 ,
                              longitude: -47.651205800398195,
                              assist_type: 3)

cons_tute = Assistance.create(name: "Conselho Tutelar do Recanto das Emas",
                              address: "Quadra 103 Conjunto 02 Casa 07",
                              phone: "(61) 3434-8517 \/ 3333-2605",
                              latitude: -15.902620676414456,
                              longitude: -48.064319512883458,
                              assist_type: 3)

cons_tute = Assistance.create(name: "Conselho Tutelar do Riacho Fundo I",
                              address: "AE 03 LT 06 – Praça Central",
                              phone: "(61) 3399-5096 \/ 3399-5026 \/ 3399-5160",
                              latitude: -15.884003430674978,
                              longitude: -48.017821771791318,
                              assist_type: 3)

cons_tute = Assistance.create(name: "Conselho Tutelar do Riacho Fundo II",
                              address: "QN 7F Conj. 04 Lote 05",
                              phone: "(61) 3434-5974 \/ 333-5489",
                              latitude: -15.901130072779315,
                              longitude: -48.048528671251589,
                              assist_type: 3)

cons_tute = Assistance.create(name: "Conselho Tutelar de Samambaia I (Sul)",
                              address: "QR 301 Conj. 04 Lote 01",
                              phone: "(61) 3357-1165 \/ 3357-3058",
                              latitude: -15.881887123222764,
                              longitude: -48.091031754671768,
                              assist_type: 3)

cons_tute = Assistance.create(name: "Conselho Tutelar de Samambaia II (Norte)",
                              address: "QS 409 Área Especial 02 em frente a 26º DP",
                              phone: "(61) 3359-7651 \/ 3459-1869 \/ 3459-7920",
                              latitude: -15.878265662011387,
                              longitude: -48.104745091467329,
                              assist_type: 3)

cons_tute = Assistance.create(name: "Conselho Tutelar de Santa Maria I (Sul)",
                              address: "Área Especial B QR 209\/309",
                              phone: "(61) 3393-5341 \/ 3393-6025 \/ 3393-6747 \/ 3393-6450",
                              latitude: -16.023632557732988,
                              longitude: -48.021498797524004,
                              assist_type: 3)

cons_tute = Assistance.create(name: "Conselho Tutelar de Santa Maria II (Norte)",
                              address: "QC 01- Área Especial- Av. Alagados",
                              phone: "(61) 3393-3106 \/ 3393-9873",
                              latitude: -16.016992399142097,
                              longitude: -48.016635018041207,
                              assist_type: 3)

cons_tute = Assistance.create(name: "Conselho Tutelar de São Sebastião",
                              address: "Área Especial S\/N, Qd. 101 Conjunto 08 – Administração - Regional de São Sebastião",
                              phone: "(61) 3335- 0147 \/ 3339-2533 \/ 3339-4961",
                              latitude: -15.899410057116921,
                              longitude: -47.775011165823436,
                              assist_type: 3)

cons_tute = Assistance.create(name: "Conselho Tutelar do SIA",
                              address: "Trecho 01 Lote 230 Bloco “A” Sala 201\/202 Edifício Bradesco – Setor de Indústria e Abastecimento – S.I.A",
                              phone: "(61) 3234-1353 \/ 3233-2166 \/ 3361-3281",
                              latitude: -15.807341010941604,
                              longitude: -47.953822033184032,
                              assist_type: 3)

cons_tute = Assistance.create(name: "Conselho Tutelar de Sobradinho I",
                              address: "Quadra 04 CL 12 Loja 06\/07",
                              phone: "(61) 3387-5707",
                              latitude: -15.652876911289166,
                              longitude: -47.801125824831665,
                              assist_type: 3)

cons_tute = Assistance.create(name: "Conselho Tutelar de Sobradinho II",
                              address: "AR 13 Conjunto 02 Casa 09",
                              phone: "(61) 3485-2794 \/ 3485-0257",
                              latitude: -15.642813866875299,
                              longitude: -47.824335819542711,
                              assist_type: 3)

cons_tute = Assistance.create(name: "Conselho Tutelar do Sudoeste\/Octogonal",
                              address: "SIG Quadra 06 LT. 1425",
                              phone: "(61) 3343-4907 \/ 3343-9364 \/ 3393-1915",
                              latitude: -15.793911781516845,
                              longitude: -47.91542881791279,
                              assist_type: 3)

cons_tute = Assistance.create(name: "Conselho Tutelar de Taguatinga I (Sul)",
                              address: "C12 Área Especial S\/N - Taguatinga Centro",
                              phone: "(61) 3562-9209 \/ 3562-9187",
                              latitude: -15.835154540675752,
                              longitude: -48.057354200624076,
                              assist_type: 3)

cons_tute = Assistance.create(name: "Conselho Tutelar de Taguatinga II (Norte)",
                              address: "QNA 33, CASA 14",
                              phone: "(61) 3562-9332 \/ 3562-9305",
                              latitude: -15.823382497595869,
                              longitude: -48.059202426382981,
                              assist_type: 3)

cons_tute = Assistance.create(name: "Conselho Tutelar do Varjão",
                              address: "Quadra 01 Conjunto D Lote 01",
                              phone: "(61) 3468-1626 \/ 3468-1579 \/ 3468-7425",
                              latitude: -15.712777135947114,
                              longitude: -47.873939645606704,
                              assist_type: 3)

cons_tute = Assistance.create(name: "Conselho Tutelar do Vicente Pires",
                              address: "Rua 12 Chácara 154\/3 Lote 38 Loja 02- Vicente Pires",
                              phone: "(61) 3435-1839 \/ 3435-1841",
                              latitude: -15.794308731672253,
                              longitude: -48.040711710473992,
                              assist_type: 3)

cons_tute = Assistance.create(name: "Conselho Tutelar de Brasília I (Sul)",
                              address: "SCS QD 03, bloco A, entrada 73, 1° Andar, Edifício Lettieri, Asa Sul",
                              phone: "(61) 3324-1701 \/ 3224-0951",
                              latitude: -15.797484812976121,
                              longitude: -47.888572077587746,
                              assist_type: 3)

#######################################################################################
# Nasf creations
require 'json'

nasf = Nasf.create(nasf_type:"Nasf-AB tipo I",
                   lotation: "Gsap 1 de Itapoã",
                   ubs: "UBS 1 Amarela 14 / UBS 1 Vermelha 13 / UBS 1 Verde 12 / UBS 1 Marrom 11,
                   UBS 1 Cinza 10 / UBS 1 Lilás 09 / UBS 1 Laranja 08 / UBS 1 Rosa 07 / UBS 1 Azul 06",
                   team: "eSF consistida + eSB",
                   specialties: "FONOAUDIÓLOGA (UBS 1 Amarela 14) / ASSISTENTE SOCIA (UBS 1 Vermelha 13) / NUTRICIONISTA (UBS 1 Verde 12) e (UBS 1 Laranja 08) / TERAPEUTA OCUPACIONAL (UBS 1 Marrom 11)/ 
                   FARMACÊUTICA (UBS 1 Cinza 10) / FISIOTERAPEUTA (UBS 1 Lilás 09)",
                   health_region: "LESTE")

nasf = Nasf.create(nasf_type:"Nasf-AB de Transição",
                   lotation: "Gsap 1 do Paranoá",
                   ubs: "UBS 1 Prata 17 / UBS 1 Laranja 16 / UBS 1 Vermelha 15 / UBS 1 Marron 14 /
                    UBS 1 Lilás 13 / UBS 1 Rosa 12 / UBS 1 Verde 11 / UBS 1 Azul 10 / UBS 1 Amarelo 09",
                   team: "eSF consistida + eSB",
                   specialties: "NUTRICIONISTA (UBS 1 Prata 17) / FARMACÊUTICO (UBS 1 Laranja 16) / PSICÓLOGA (UBS 1 Vermelha 15) / ASSISTENTE SOCIAL (UBS 1 Marron 14)",
                   health_region: "LESTE")

nasf = Nasf.create(nasf_type:"Nasf-AB tipo I",
                   lotation: "Gsap 1 São Sebastião",
                   ubs: "UBS 1 Vermelha 10 / UBS 1 Verde 09 / UBS 1 Rosa 08 / UBS 1 Lílas 07
                   / UBS 1 Amarela 06 / UBS 1 Azul 05 / UBS 1 Laranja 04 / UBS 1 Central 3 / UBS 1 Central 2",
                   team: "Todas as equipes são (eSF consistida + eSB),
                   com exceção da UBS 1 Laranja 04, UBS 1 Azul 05, UBS 1 Amarela 06 e
                   UBS 1 Lílas 07, que são (eSF sem ACS + eSB)",
                   specialties: "NUTRICIONISTA (UBS 1 Vermelha 10) / FONOAUDIÓLOGA (UBS 1 Verde 09) / FARMACÊUTICO (UBS 1 Rosa 08) / PSICÓLOGA (UBS 1 Lílas 07) / ASSISTENTE SOCIAL (UBS 1 Amarela 06) e (UBS 1 Azul 05)",
                   health_region: "LESTE")

nasf = Nasf.create(nasf_type:"Nasf-AB de Transição",
                   lotation: "Gsap 5 SSB - Paranoá Parque",
                   ubs: "UBS Paranoá Parque / UBS 2 P Quadra 18 / UBS 2 P Sob. Dos Melos / UBS 7 Café sem Troco",
                   team: "eSF consistida + eSB, com exceção da UBS Paranoá Parque que está em formação",
                   specialties: "TERAPEUTA OCUPACIONAL(UBS Paranoá Parque) / FISIOTERAPEUTA(UBS Paranoá Parque) / PSICÓLOGA (UBS Paranoá Parque)",
                   health_region: "LESTE")

nasf = Nasf.create(nasf_type:"Nasf-AB de Transição",
                   lotation: "Gsap 2 de Brazlândia",
                   ubs: "UBS 2 de Brazlândia / UBS 3 de Brazlândia / 
                   UBS 4 de Brazlândia / UBS 5 de Brazlândia/ 
                   UBS 6 de Brazlândia",
                   team: "ESFSB M1-02, ESF 04, ESF 09, ESFSB M1-10 (UBS 2 de Brazlândia) / ESFSB M1-06 (UBS 3 de Brazlândia) / ESF 07 (UBS 4 de Brazlândia) / ESFSB M1-05, ESF 13 (UBS 5 de Brazlândia) / ESF 03 (UBS 6 de Brazlândia)",
                   specialties: "ASSISTENTE SOCIAL (UBS 2 de Brazlândia) / NUTRICIONISTA (UBS 2 de Brazlândia) / FISIOTERAPEUTA (UBS 2 de Brazlândia) / FARMACÊUTICO (UBS 2 de Brazlândia) / TERAPEUTA OCUPACIONAL (UBS 3 de Brazlândia)",
                   health_region: "OESTE")

nasf = Nasf.create(nasf_type:"Nasf-AB tipo I",
                   lotation: "Gsap 8 de Ceilândia",
                   ubs: "UBS 1 de Ceilândia / UBS 8 de Ceilândia",
                   team: "ESFSB M1-18, ESFSB M1-19, ESF 22 (UBS 1 de Ceilândia) / EAB 01, ESF 07, ESF 28, ESFSB M1-13, ESFSB M1- 10, ESFSB M1-17 (UBS 8 de Ceilândia)",
                   specialties: "NUTRICIONISTA (UBS 1 de Ceilândia)/ FISIOTERAPEUTA (UBS 1 de Ceilândia) / FARMACÊUTICO (UBS 1 de Ceilândia) / TERAPEUTA OCUPACIONAL (UBS 8 de Ceilândia) / ASSISTENTE SOCIAL (UBS 8 de Ceilândia)",
                   health_region: "OESTE")

nasf = Nasf.create(nasf_type:"Nasf-AB tipo I",
                   lotation: "Gsap 6 de Ceilândia",
                   ubs: "UBS 6 de Ceilândia",
                   team: "EAB 02, EAB 03, EAB 04, EAB 05",
                   specialties: "NUTRICIONISTA / FARMACÊUTICO / ASSISTENTE SOCIAL / TERAPEUTA OCUPACIONAL / NUTRICIONISTA / FISIOTERAPEUTA ",
                   health_region: "OESTE")

nasf = Nasf.create(nasf_type:"Nasf-AB de Transição",
                   lotation: "Gsap 7  de Ceilândia",
                   ubs: "UBS 7 de Ceilândia",
                   team: "EAB 01, EAB 02, EAB 03, EAB 04",
                   specialties: "NUTRICIONISTA / FARMACÊUTICO / ASSISTENTE SOCIAL / ASSISTENTE SOCIAL / FISIOTERAPEUTA",
                   health_region: "OESTE")

nasf = Nasf.create(nasf_type:"Nasf-AB tipo I",
                   lotation: "Gsap 10  de Ceilândia",
                   ubs: "UBS 10 de Ceilândia",
                   team: "ESF 37, ESF 38, ESFSB M1-04, ESF 06",
                   specialties: "NUTRICIONISTA / FISIOTERAPEUTA / ASSISTENTE SOCIAL / ASSISTENTE SOCIAL / FARMACÊUTICO / TERAPEUTA OCUPACIONAL",
                   health_region: "OESTE")

nasf = Nasf.create(nasf_type:"Nasf-AB tipo I",
                   lotation: "Gsap 12  de Ceilândia",
                   ubs: "UBS 12 de Ceilândia",
                   team: "EAB 05, EAB 06, EAB 08, EAB 12",
                   specialties: "NUTRICIONISTA / FISIOTERAPEUTA / ASSISTENTE SOCIAL / ASSISTENTE SOCIAL / TERAPEUTA OCUPACIONAL / PSICÓLOGA",
                   health_region: "OESTE")

nasf = Nasf.create(nasf_type:"Nasf-AB de Transição",
                   lotation: "Gsap 1 de Brazlândia",
                   ubs: "UBS 1 de Brazlândia",
                   team: "ESFSB M1-14, EAB 03 , EAB 02, EAB 01 ",
                   specialties: "ASSISTENTE SOCIAL / NUTRICIONISTA / FARMACÊUTICO",
                   health_region: "OESTE")

nasf = Nasf.create(nasf_type:"Nasf-AB de Transição",
                   lotation: "Gsap 02  de Ceilândia",
                   ubs: "UBS 02 de Ceilândia",
                   team: "EAB 01, EAB 02, EAB 03, EAB 04",
                   specialties: "NUTRICIONISTA / ASSISTENTE SOCIAL / FISIOTERAPEUTA / TERAPEUTA OCUPACIONAL",
                   health_region: "OESTE")

nasf = Nasf.create(nasf_type:"Nasf-AB tipo I",
                   lotation: "Gsap 7 de Samambaia",
                   ubs: "UBS 7 de Samambaia / UBS 10 de Samambaia",
                   team: "UBS 7 de Samambaia (Equipe 14, Equipe 37 + SB, Equipe 41 + SB, Equipe 51+ SB, Equipe 18 , Equipe 45) / Equipe 08 (UBS 10) - mesma GSAP",
                   specialties: " UBS 7 de Samambaia (FARMACÊUTICO, ASSISTENTE SOCIAL, NUTRICIONISTA, PSICÓLOGO, FISIOTERAPEUTA)",
                   health_region: "SUDOESTE")

nasf = Nasf.create(nasf_type:"Nasf-AB de Transição",
                   lotation: "Gsap 3 de Recanto das Emas",
                   ubs: "UBS 3 do Recanto das Emas",
                   team: "EQUIPE 18 + SB, EQUIPE 19 + SB, EQUIPE 20 + SB, EQUIPE 21 INCONSISTIDA, EQUIPE 22, EQUIPE 23 + SB, EQUIPE 24 INCONSISTIDA",
                   specialties: "ASSITENTE SOCIAL, FISIOTERAPEUTA, NUTRICIONISTA, TERAPEUTA OCUPACIONAL",
                   health_region: "SUDOESTE")

nasf = Nasf.create(nasf_type:"Nasf-AB tipo I",
                   lotation: "Gsap 4 de Recanto das Emas",
                   ubs: "UBS 4 do Recanto das Emas",
                   team: "EQUIPE 6 + SB, EQUIPE 10 + SB, EQUIPE 14 INCONSISTIDA, EQUIPE 15, EQUIPE 16 +SB, EQUIPE 17 +SB",
                   specialties: "ASSISTENTE SOCIAL / FARMACÊUTICO / FONAUDIOLOGA / NUTRICIONISTA / PSICÓLOGO",
                   health_region: "SUDOESTE")

nasf = Nasf.create(nasf_type:"Nasf-AB tipo I",
                   lotation: "Gsap 1 de Taguatinga",
                   ubs: "UBS 1 de Taguatinga",
                   team: "EQUIPE 1 UBS 1 + SB, EQUIPE 4 UBS 1 +SB, EQUIPE 2 UBS 1, EQUIPE 3 UBS 1, ESF INCONSISTIDA, ESF INCONSISTIDA, EQUIPE EENF",
                   specialties: "ASSISTENTE SOCIAL / FARMACÊUTICO / NUTRICIONISTA / FISIOTERAPEUTA / FONOAUDIÓLOGO",
                   health_region: "SUDOESTE")

nasf = Nasf.create(nasf_type:"Nasf-AB tipo I",
                   lotation: "Gsap 1 de Águas Claras",
                   ubs: "UBS 1 de Águas Claras / UBS 2 de Águas Claras",
                   team: "UBS 1 de Águas Claras (EQUIPE 2 AGUAS CLARAS + SB, EQUIPE 3 AGUAS CLARAS +SB, EQUIPE 4 AGUAS CLARAS +SB, EQUIPE 5 AGUAS CLARAS, EQUIPE 6 AGUAS CLARAS) /
                    UBS 2 de Águas Claras (EQUIPE 1 AGUAS CLARAS + SB)",
                   specialties: " UBS 2 de Águas Claras (ASSISTENTE SOCIAL, FARMACÊUTICO, NUTRICIONISTA, PSICÓLOGO, FISIOTERAPEUTA)",
                   health_region: "SUDOESTE")

nasf = Nasf.create(nasf_type:"Nasf-AB de Transição",
                   lotation: "Gsap 3 de Taguatinga",
                   ubs: "UBS 3 de Taguatinga",
                   team: "Equipe 1 UBS 3 +SB, Equipe 2 UBS 3 + SB, Equipe 3 UBS 3 + SB, Equipe EENF",
                   specialties: "ASSISTENTE SOCIAL, FARMACÊUTICO, NUTRICIONISTA",
                   health_region: "SUDOESTE")

nasf = Nasf.create(nasf_type:"Nasf-AB de Transição",
                   lotation: "Gsap 5 de Taguatinga",
                   ubs: "UBS 5 de Taguatinga",
                   team: "Equipe 1 UBS 5, Equipe 2 UBS 5, Equipe 3 UBS 5 + SB, Equipe Consultório na Rua",
                   specialties: "FARMACÊUTICO, ASSISTENTE SOCIAL, NUTRICIONISTA",
                   health_region: "SUDOESTE")

nasf = Nasf.create(nasf_type:"Nasf-AB de Transição",
                   lotation: "Gsap 6 de Taguatinga",
                   ubs: "UBS 6 de Taguatinga",
                   team: "Equipe 1 UBS 6 +SB, Equipe 2 UBS 6, Equipe 3 UBS 6 + SB, Esf inconsistida",
                   specialties: "ASSISTENTE SOCIAL, FARMACÊUTICO, NUTRICIONISTA",
                   health_region: "SUDOESTE")

nasf = Nasf.create(nasf_type:"Nasf-AB de Transição",
                   lotation: "Gsap 7 de Taguatinga",
                   ubs: "UBS 7 de Taguatinga",
                   team: "Equipe 3 UBS 7 + SB, Equipe 4 UBS 7 +SB, Equipe 7 UBS 7, Equipe 2 UBS 7",
                   specialties: "FARMACÊUTICO, NUTRICIONISTA, ASSISTENTE SOCIAL",
                   health_region: "SUDOESTE")

nasf = Nasf.create(nasf_type:"Nasf-AB de Transição",
                   lotation: "Gsap 8 de Taguatinga",
                   ubs: "UBS 8 de Taguatinga",
                   team: "Equipe 8 UBS 8, Equipe 2 UBS 8 +SB, Equipe 4 UBS 8 + SB, Equipe 3 UBS 8 ",
                   specialties: "FARMACÊUTICO, ASSISTENTE SOCIAL",
                   health_region: "SUDOESTE")

nasf = Nasf.create(nasf_type:"Nasf-AB de Transição",
                   lotation: "Gsap 1 de Vicente Pires",
                   ubs: "UBS 1 de Vicente PiresS",
                   team: "Equipe 1 Vicente Pires e Esf inconsistida",
                   specialties: "FARMACÊUTICO, ASSISTENTE SOCIAL, NUTRICIONISTA",
                   health_region: "SUDOESTE")

nasf = Nasf.create(nasf_type:"Nasf-AB de Transição",
                   lotation: "Gsap 2 de Samambaia",
                   ubs: "UBS 2 de Samambaia",
                   team: "equipe 27 , equipe 28, equipe 29+ S, equipe 31 ",
                   specialties: "FARMACÊUTICO, FISIOTERAPEUTA, ASSISTENTE SOCIAL",
                   health_region: "SUDOESTE")

nasf = Nasf.create(nasf_type:"Nasf-AB de Transição",
                   lotation: "Gsap 3 de Samambaia",
                   ubs: "UBS 3 de Samambaia",
                   team: "EQUIPE 7 + SB, EQUIPE 9 + SB, EQUIPE 46, EQUIPE 47",
                   specialties: "FARMACÊUTICO, FISIOTERAPEUTA, NUTRICIONISTA, ASSISTENTE SOCIAL",
                   health_region: "SUDOESTE")

nasf = Nasf.create(nasf_type:"Nasf-AB de Transição",
                   lotation: "Gsap 2 de Recanto das Emas",
                   ubs: "UBS 2 do Recanto das Emas",
                   team: "EQUIPE 7 + SB, EQUIPE 26 + SB, ESF EQUIPE 1 DA UBS 2 +SB, eSF inconsistida ",
                   specialties: "ASSISTENTE SOCIAL, FARMACÊUTICO, NUTRICIONISTA, PSICÓLOGA",
                   health_region: "SUDOESTE")

nasf = Nasf.create(nasf_type:"Nasf-AB tipo I",
                   lotation: "Gsap 3 da ASA NORTE",
                   ubs: "UBS 1 da ASA NORTE / UBS 3 da VILA PLANALTO",
                   team: "UBS 1 da ASA NORTE (eSF consistida + eSB) / UBS 3 da VILA PLANALTO (eSF incosistida)",
                   specialties: "UBS 1 da ASA NORTE (PSICÓLOGA, FARMACEUTICO, NUTRICIONISTA, ASSISTENTE SOCIA) / UBS 3 da VILA PLANALTO (FISIOTERAPEUTA, NUTRICIONISTA)",
                   health_region: "CENTRAL")

nasf = Nasf.create(nasf_type:"Nasf-AB tipo I",
                   lotation: "Gsap 1 do VARJÃO",
                   ubs: "UBS 1 do VARJÃO / UBS 1 do LAGO NORTE / UBS GRANJA DO TORTO",
                   team: "Todas são eSF consistida + eSB",
                   specialties: "UBS 1 do VARJÃO (NUTRICIONISTA , FARMACEUTICO, ASSISTENTE SOCIAL) / UBS 1 do LAGO NORTE (TERAPEUTA OCUPACIONAL, FISIOTERAPEUTA, NUTRICIONISTA)",
                   health_region: "CENTRAL")

nasf = Nasf.create(nasf_type:"Nasf-AB tipo I",
                   lotation: "Gsap 1 da ASA SUL",
                   ubs: "UBS 1 da ASA SUL",
                   team: "eSF consistida + eSB",
                   specialties: "NUTRICIONISTA, FARMACÊUTICA, ASSISTENTE SOCIAL, PSICÓLOGA, TERAPEUTA OCUPAC.",
                   health_region: "CENTRAL")

nasf = Nasf.create(nasf_type:"Nasf-AB de Transição",
                   lotation: "Gsap 2 da ASA NORTE",
                   ubs: "UBS 2 da ASA NORTE",
                   team: "eSF consistida + eSB",
                   specialties: "FARMACÊUTICA, NUTRICIONISTA, PSICÓLOGA",
                   health_region: "CENTRAL")

nasf = Nasf.create(nasf_type:"Nasf-AB de Transição",
                   lotation: "Gsap 1  do CRUZEIRO",
                   ubs: "Gsap 1  do CRUZEIRO",
                   team: "eSF consistida + eSB",
                   specialties: "FARMACÊUTICA, NUTRICIONISTA ",
                   health_region: "CENTRAL")

nasf = Nasf.create(nasf_type:"Nasf-AB de Transição",
                   lotation: "Gsap 2  do CRUZEIRO",
                   ubs: "UBS 2 do CRUZEIRO VELHO",
                   team: "eSF consistida + eSB",
                   specialties: "NUTRICIONISTA, PSICÓLOGA, ASSITENTE SOCIAL",
                   health_region: "CENTRAL")

nasf = Nasf.create(nasf_type:"Nasf-AB tipo I",
                   lotation: "Gsap 6 de Sobradinho",
                   ubs: "UBS 3 de Sobradinho II / UBS 4 de Sobradinho II / UBS 5 de Sobradinho II / UBS 6 de Sobradinho II / UBS 1 de Fercal / UBS 2 de Fercal",
                   team: "01 eSF consistida +   01eSB (UBS 3 de Sobradinho II, UBS 4 de Sobradinho II) / 02 eSF consistidas + 01 eSB (UBS 5 de Sobradinho II)
                           / 01 eSF consistida (01 eSF consistida, UBS 2 de Fercal) / 03 eSF consistidas + 02eSB (UBS 1 de Fercal)",
                   specialties: "ASSISTENTE SOCIAL (UBS 3 de Sobradinho II) / NUTRICIONISTA (UBS 4 de Sobradinho II) /  FISIOTERAPEUTA (UBS 5 de Sobradinho II) /  TERAPEUTA OCUPACIONAL (UBS 6 de Sobradinho II) /  PSICÓLOGO (UBS 1 de Fercal)",
                   health_region: "NORTE")

nasf = Nasf.create(nasf_type:"Nasf-AB tipo I",
                   lotation: "Gsap 8 de Planaltina",
                   ubs: "UBS 4 de Planaltina",
                   team: "Não Disponivel",
                   specialties: "ASSISTENTE SOCIAL, ASSISTENTE SOCIAL, FISIOTERAPEUTA, FARMACÊUTICO, NUTRICIONISTA, FONOAUDIÓLOGO",
                   health_region: "NORTE")

nasf = Nasf.create(nasf_type:"Nasf-AB de Transição",
                   lotation: "Gsap 2 de Planaltina",
                   ubs: "UBS 2 de Planaltina",
                   team: "eSF consistida + eSB",
                   specialties: "ASSISTENTE SOCIAL, NUTRICIONISTA, FARMACÊUTICO",
                   health_region: "NORTE")

nasf = Nasf.create(nasf_type:"Nasf-AB de Transição",
                   lotation: "Gsap 9 de Planaltina",
                   ubs: "UBS 5 de Planaltina",
                   team: "eSF consistida + eSB",
                   specialties: "ASSISTENTE SOCIAL, PSICÓLOGO, FARMACÊUTICO, NUTRICIONISTA, FISIOTERAPEUTA",
                   health_region: "NORTE")

nasf = Nasf.create(nasf_type:"Nasf-AB de Transição",
                   lotation: "Gsap 4 de Sobradinho",
                   ubs: "UBS 3 de Sobradinho",
                   team: "eSF consistida + eSB",
                   specialties: "ASSISTENTE SOCIAL, PSICÓLOGO, FISIOTERAPEUTA, NUTRICIONISTA",
                   health_region: "NORTE")

nasf = Nasf.create(nasf_type:"Nasf-AB tipo I",
                   lotation: "Gsap 1 do Gama",
                   ubs: "UBS 1 do Gama / UBS 2 do Gama",
                   team: "UBS 1 do Gama (220/36, 248/27, 215/13, 213/11, 235/14) / UBS 2 do Gama (242/21, 208/06, 250/29, 232/31)",
                   specialties: "UBS 1 do Gama (ASSISTENTE SOCIAL, NUTRICIONISTA, PSICOLOGO, FISIOTERAPEUTA, FARMACEUTICO BIOQ. FARMACIA)",
                   health_region: "SUL")

nasf = Nasf.create(nasf_type:"Nasf-AB tipo I",
                   lotation: "Gsap 6 do Gama",
                   ubs: "UBS 6 do Gama / UBS 5 do Gama / UBS 11 do Gama",
                   team: "UBS 6 do Gama (217/32, 246/25, 214/12, 240/19) / UBS 5 do Gama (221/37) / UBS 11 do Gama (204/02, 223/38)",
                   specialties: "UBS 6 do Gama (ASSISTENTE SOCIAL, FISIOTERAPEUTA, PSICOLOGO, FONOAUDIÓLOGO, NUTRICIONISTA, FARMACEUTICO)",
                   health_region: "SUL")

nasf = Nasf.create(nasf_type:"Nasf-AB de Transição",
                   lotation: "Gsap 1 de Santa Maria",
                   ubs: "UBS 1 de Santa Maria",
                   team: "527/10, 523/06, 529/12, Equipe inconsistida",
                   specialties: "FARMACEUTICO, TERAPEUTA OCUPACIONAL",
                   health_region: "SUL")

nasf = Nasf.create(nasf_type:"Nasf-AB de Transição",
                   lotation: "Gsap 3 do Gama",
                   ubs: "UBS 3 do Gama / UBS 4 do Gama",
                   team: "UBS 3 do Gama (237/16, 243/22, 219/34, 218/33, 209/07) / UBS 4 do Gama (207/05, 238/17, 210/08, 222/35)",
                   specialties: "UBS 3 do Gama (FARMACEUTICO, ASSISTENTE SOCIAL, NUTRICIONISTA) / UBS 4 do Gama (ASSISTENTE SOCIAL, FISIOTERAPEUTA)",
                   health_region: "SUL")

nasf = Nasf.create(nasf_type:"Nasf-AB de Transição",
                   lotation: "Gsap 2 de Santa Maria",
                   ubs: "UBS 2 de Santa Maria",
                   team: "531/14, 530/13, 524/07, Equipe inconsistida",
                   specialties: "NUTRICIONISTA, FARMACEUTICO, ASSISTENTE SOCIAL",
                   health_region: "SUL")

nasf = Nasf.create(nasf_type:"Nasf-AB tipo I",
                   lotation: "GSAP 1 Estrutural",
                   ubs: "UBS 1 da Estrutural",
                   team: "Não Disponivel",
                   specialties: "FARMACÊUTICO, ASSISTENTE SOCIAL, NUTRICIONISTA, FISIOTERAPEUTA, FONOAUDIÓLOGO",
                   health_region: "CENTRO-SUL")

nasf = Nasf.create(nasf_type:"Nasf-AB tipo I",
                   lotation: "GSAP 1 Riacho Fundo II",
                   ubs: "UBS 1 do Rio Fundo II / UBS 4 do Rio Fundo II",
                   team: "Não Disponivel",
                   specialties: "UBS 1 do Rio Fundo II (FARMACÊUTICO) / UBS 4 do Rio Fundo II (ASSISTENTE SOCIAL, NUTRICIONISTA, FONOAUDIÓLOGO, ASSISTENTE SOCIAL, FISIOTERAPEUTA)",
                   health_region: "CENTRO-SUL")

nasf = Nasf.create(nasf_type:"Nasf-AB tipo I",
                   lotation: "GSAP 3 Guará",
                   ubs: "UBS 1 do Guará / UBS 4 do Guará",
                   team: "Não Disponivel",
                   specialties: "UBS 1 do Guará (FARMACÊUTICO) / UBS 4 do Guará (ASSISTENTE SOCIAL, NUTRICIONISTA, FISIOTERAPEUTA, PSICÓLOGO)",
                   health_region: "CENTRO-SUL")

nasf = Nasf.create(nasf_type:"Nasf-AB tipo I",
                   lotation: "GSAP 1 Núcleo Bandeirantes",
                   ubs: "UBS 1 Núcleo Bandeirantes / UBS 2 Núcleo Bandeirantes",
                   team: "Não Disponivel",
                   specialties: "UBS 1 Núcleo Bandeirantes (FARMACÊUTICO) / UBS 2 Núcleo Bandeirantes (ASSISTENTE SOCIAL, NUTRICIONISTA, FISIOTERAPEUTA, PSICÓLOGO)",
                   health_region: "CENTRO-SUL")

nasf = Nasf.create(nasf_type:"Nasf-AB de Transição",
                   lotation: "GSAP 1 Riacho Fundo I",
                   ubs: "UBS 1 do Riacho Fundo I / UBS 2 do Riacho Fundo I",
                   team: "Não Disponivel",
                   specialties: "UBS 1 do Riacho Fundo I (FARMACÊUTICO) / UBS 2 do Riacho Fundo I (ASSISTENTE SOCIAL, NUTRICIONISTA, FISIOTERAPEUTA, PSICÓLOGO)",
                   health_region: "CENTRO-SUL")

nasf = Nasf.create(nasf_type:"Nasf-AB tipo I",
                   lotation: "GSAP 1 Guará",
                   ubs: "UBS 1 do Guará",
                   team: "Não Disponivel",
                   specialties: "FARMACÊUTICO, ASSISTENTE SOCIAL, FISIOTERAPEUTA, TERAPEUTA OCUPACIONAL, NUTRICIONISTA, NUTRICIONISTA",
                   health_region: "CENTRO-SUL")

nasf = Nasf.create(nasf_type:"Nasf-AB de Transição",
                   lotation: "GSAP 1 Estrutural",
                   ubs: "UBS 2 da Estrutural",
                   team: "Não Disponivel",
                   specialties: "TERAPEUTA OCUPACIONAL, NUTRICIONISTA, ASSISTENTE SOCIAL",
                   health_region: "CENTRO-SUL")

nasf = Nasf.create(nasf_type:"Nasf-AB de Transição",
                   lotation: "GSAP 2 Guará",
                   ubs: "UBS 2 do Guará",
                   team: "Não Disponivel",
                   specialties: "FARMACÊUTICO, ASSISTENTE SOCIAL, NUTRICIONISTA",
                   health_region: "CENTRO-SUL")

nasf = Nasf.create(nasf_type:"Nasf-AB de Transição",
                   lotation: "GSAP 1 Candangolândia",
                   ubs: "UBS 1 da Candangolândia",
                   team: "Não Disponivel",
                   specialties: "FARMACÊUTICO, ASSISTENTE SOCIAL, NUTRICIONISTA, ASSISTENTE SOCIAL",
                   health_region: "CENTRO-SUL")