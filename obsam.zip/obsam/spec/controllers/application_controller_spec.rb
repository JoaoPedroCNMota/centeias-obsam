require 'rails_helper'

RSpec.describe ApplicationController, type: :controller do
end
