require 'rails_helper'

RSpec.describe DevicesRequestsController, type: :controller do
  describe 'CRUD of requests devices' do
    before(:each) do
      @devicerequests = DevicesRequest.create(user_id: 1,
                                              status: 2,
                                              request_type: 1,
                                              caps_id: nil,
                                              device_id: nil,
                                              name: 'device test',
                                              address: 'endereço test',
                                              city: 'cidade teste',
                                              uf: 'uf teste',
                                              cep: '00000000',
                                              phone1: '12345678',
                                              phone2: '12345678',
                                              email: 'teste@teste.com',
                                              website: 'web site teste',
                                              public_policy: 'politica publica teste',
                                              operation_days: 'dias de funcionamento',
                                              working_hours: 'horas de trabalho teste',
                                              target_audience: '',
                                              ad_area:'',
                                              first_attendance_time:'',
                                              first_attendance_documentation:'',
                                              device_description:'descrição teste dos dispositivos',
                                              latitude: -15.646743062218784,
                                              longitude: -47.816545916389522)
    end


  end
end