require 'rails_helper'

RSpec.describe UsersController, type: :controller do
  describe 'CRUD of logged user with login admin' do
    before(:each) do
      @user = User.create(name: 'test.admin@admin.com',
                          username: 'test',
                          password: '123456',
                          password_digest: '123456',
                          admin: true)
      session[:user_id] = @user.id
    end

    it 'should render index page' do
      get :index
      expect(response).to be_success
      expect(response).to have_http_status(200)
    end

    it 'should render register page logged' do
      get :new
      expect(response).to have_http_status(200)
    end

    it 'should render edit page logged' do
      get :edit, params:{id: @user.id}
      expect(response).to have_http_status(200)
    end

    it 'should create new user' do
      post :create, params: { user: { name: 'testname',
                                      username: 'testuser',
                                      password: '123456',
                                      password_confirmation: '123456',
                                      admin: true } }
      expect(flash[:success]).to eq('Conta criada com sucesso')
    end

    it 'should not create user without name' do
      post :create, params: { user: { name: '',
                                      username: 'testuser',
                                      password: '123456',
                                      password_confirmation: '123456',
                                      admin: true } }
      expect(User.last.name).not_to eq('')
    end

    it 'should update user' do
      put :update, params: { id: @user.id, user: {name: 'testname1',
                                                  username: 'testuser1',
                                                  password: '123456',
                                                  password_confirmation: '123456',
                                                  admin: true } }
      expect(flash[:success]).to eq('Conta atualizada com sucesso')
    end

    it 'should not update user' do
      put :update, params: { id: @user.id, user: {name: '',
                                                  username: 'testuser1',
                                                  password: '123456',
                                                  password_confirmation: '123456',
                                                  admin: true } }
      expect(User.last.name).not_to eq('')
    end

    it 'should delete user account' do
      get :destroy, params:{id: @user.id}
      expect(flash[:success]).to eq('Conta apagada com sucesso')
    end

  end

  describe 'without logged(before each) user with login admin' do
    it 'should not render index page' do
      get :index
      expect(response).to have_http_status(302)
    end    
  end

end
