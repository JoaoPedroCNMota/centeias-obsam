RSpec.describe CapsRequestsHelper, type: :helper do

end