require 'rails_helper'

RSpec.describe SessionsHelper, type: :helper do
  describe 'loggin and logout tests' do
    before(:each) do
      User.create(name: 'Administrator',
         								  username: 'admin@obsam',
         								  password: 'obsam1',
         								  password_confirmation: 'obsam1',
         								  admin: true)
      @user = User.last
    end

    it 'should open loggin page' do
      log_in(@user)
      expect(session[:user_id]).to eq(@user.id)
    end

    it 'current user should be the actual logger' do
      log_in(@user)

      expect(current_user).to eq(@user)
    end

    it 'logged_in? should be true with if the user are logged' do
      log_in(@user)

      expect(logged_in?).to eq(true)
    end

    it 'current user should be nil after log_out' do
      log_in(@user)
      log_out
      expect(current_user).to eq(nil)
    end
  end
end
