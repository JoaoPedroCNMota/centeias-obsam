require 'rails_helper'
include SessionsHelper

RSpec.describe UsersHelper, type: :helper do
  describe 'users help tests' do
    before(:each) do
      User.create(name: 'Administrator',
                          username: 'admin@obsam',
                          password: 'obsam1',
                          password_confirmation: 'obsam1',
                          admin: true)
      @user = User.last
    end

    it 'should not redirect to login_path if logged in' do
      log_in(@user)
      require_login

      expect(response).to have_http_status(200)
      expect(flash[:danger]).to eq(nil)
    end

  end
end