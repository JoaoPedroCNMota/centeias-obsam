require "rails_helper"

RSpec.describe NasfsController, type: :routing do
  describe "routing" do

    it "routes to #index" do
      expect(:get => "/nasfs").to route_to("nasfs#index")
    end

    it "routes to #new" do
      expect(:get => "/nasfs/new").to route_to("nasfs#new")
    end

    it "routes to #show" do
      expect(:get => "/nasfs/1").to route_to("nasfs#show", :id => "1")
    end

    it "routes to #edit" do
      expect(:get => "/nasfs/1/edit").to route_to("nasfs#edit", :id => "1")
    end

    it "routes to #create" do
      expect(:post => "/nasfs").to route_to("nasfs#create")
    end

    it "routes to #update via PUT" do
      expect(:put => "/nasfs/1").to route_to("nasfs#update", :id => "1")
    end

    it "routes to #update via PATCH" do
      expect(:patch => "/nasfs/1").to route_to("nasfs#update", :id => "1")
    end

    it "routes to #destroy" do
      expect(:delete => "/nasfs/1").to route_to("nasfs#destroy", :id => "1")
    end

  end
end
