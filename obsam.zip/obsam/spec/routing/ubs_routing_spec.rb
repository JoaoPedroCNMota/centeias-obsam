require "rails_helper"

RSpec.describe UbsController, type: :routing do
  describe "routing" do

    it "routes to #index" do
      expect(:get => "/ubs").to route_to("ubs#index")
    end

    it "routes to #new" do
      expect(:get => "/ubs/new").to route_to("ubs#new")
    end

    it "routes to #show" do
      expect(:get => "/ubs/1").to route_to("ubs#show", :id => "1")
    end

    it "routes to #edit" do
      expect(:get => "/ubs/1/edit").to route_to("ubs#edit", :id => "1")
    end

    it "routes to #create" do
      expect(:post => "/ubs").to route_to("ubs#create")
    end

    it "routes to #update via PUT" do
      expect(:put => "/ubs/1").to route_to("ubs#update", :id => "1")
    end

    it "routes to #update via PATCH" do
      expect(:patch => "/ubs/1").to route_to("ubs#update", :id => "1")
    end

    it "routes to #destroy" do
      expect(:delete => "/ubs/1").to route_to("ubs#destroy", :id => "1")
    end

  end
end
