require 'rails_helper'

RSpec.describe "nasfs/edit", type: :view do
  before(:each) do
    @nasf = assign(:nasf, Nasf.create!(
      :nasf_type => "MyString",
      :lotation => "MyString",
      :ubs => "MyString",
      :team => "MyString",
      :specialties => "MyString",
      :health_region => "MyString",
      :geojson => ""
    ))
  end

  it "renders the edit nasf form" do
    render

    assert_select "form[action=?][method=?]", nasf_path(@nasf), "post" do

      assert_select "input[name=?]", "nasf[nasf_type]"

      assert_select "input[name=?]", "nasf[lotation]"

      assert_select "input[name=?]", "nasf[ubs]"

      assert_select "input[name=?]", "nasf[team]"

      assert_select "input[name=?]", "nasf[specialties]"

      assert_select "input[name=?]", "nasf[health_region]"

      assert_select "input[name=?]", "nasf[geojson]"
    end
  end
end
