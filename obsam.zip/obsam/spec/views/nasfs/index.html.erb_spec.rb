require 'rails_helper'

RSpec.describe "nasfs/index", type: :view do
  before(:each) do
    assign(:nasfs, [
      Nasf.create!(
        :nasf_type => "Nasf Type",
        :lotation => "Lotation",
        :ubs => "Ubs",
        :team => "Team",
        :specialties => "Specialties",
        :health_region => "Health Region",
        :geojson => ""
      ),
      Nasf.create!(
        :nasf_type => "Nasf Type",
        :lotation => "Lotation",
        :ubs => "Ubs",
        :team => "Team",
        :specialties => "Specialties",
        :health_region => "Health Region",
        :geojson => ""
      )
    ])
  end

  it "renders a list of nasfs" do
    render
    assert_select "tr>td", :text => "Nasf Type".to_s, :count => 2
    assert_select "tr>td", :text => "Lotation".to_s, :count => 2
    assert_select "tr>td", :text => "Ubs".to_s, :count => 2
    assert_select "tr>td", :text => "Team".to_s, :count => 2
    assert_select "tr>td", :text => "Specialties".to_s, :count => 2
    assert_select "tr>td", :text => "Health Region".to_s, :count => 2
    assert_select "tr>td", :text => "".to_s, :count => 2
  end
end
