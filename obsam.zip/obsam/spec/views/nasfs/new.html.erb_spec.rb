require 'rails_helper'

RSpec.describe "nasfs/new", type: :view do
  before(:each) do
    assign(:nasf, Nasf.new(
      :nasf_type => "MyString",
      :lotation => "MyString",
      :ubs => "MyString",
      :team => "MyString",
      :specialties => "MyString",
      :health_region => "MyString",
      :geojson => ""
    ))
  end

  it "renders new nasf form" do
    render

    assert_select "form[action=?][method=?]", nasfs_path, "post" do

      assert_select "input[name=?]", "nasf[nasf_type]"

      assert_select "input[name=?]", "nasf[lotation]"

      assert_select "input[name=?]", "nasf[ubs]"

      assert_select "input[name=?]", "nasf[team]"

      assert_select "input[name=?]", "nasf[specialties]"

      assert_select "input[name=?]", "nasf[health_region]"

      assert_select "input[name=?]", "nasf[geojson]"
    end
  end
end
