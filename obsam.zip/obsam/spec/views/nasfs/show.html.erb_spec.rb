require 'rails_helper'

RSpec.describe "nasfs/show", type: :view do
  before(:each) do
    @nasf = assign(:nasf, Nasf.create!(
      :nasf_type => "Nasf Type",
      :lotation => "Lotation",
      :ubs => "Ubs",
      :team => "Team",
      :specialties => "Specialties",
      :health_region => "Health Region",
      :geojson => ""
    ))
  end

  it "renders attributes in <p>" do
    render
    expect(rendered).to match(/Nasf Type/)
    expect(rendered).to match(/Lotation/)
    expect(rendered).to match(/Ubs/)
    expect(rendered).to match(/Team/)
    expect(rendered).to match(/Specialties/)
    expect(rendered).to match(/Health Region/)
    expect(rendered).to match(//)
  end
end
