require 'rails_helper'

RSpec.describe "ubs/index", type: :view do
  before(:each) do
    assign(:ubs, [
      Ub.create!(
        :cnes => "Cnes",
        :name => "Name",
        :adress => "Adress",
        :cep => "Cep",
        :unity_type => "Unity Type",
        :working_hours => "Working Hours",
        :drugstore => "Drugstore",
        :dental_care => "Dental Care",
        :latitude => 2.5,
        :longitude => 3.5,
        :geojson => ""
      ),
      Ub.create!(
        :cnes => "Cnes",
        :name => "Name",
        :adress => "Adress",
        :cep => "Cep",
        :unity_type => "Unity Type",
        :working_hours => "Working Hours",
        :drugstore => "Drugstore",
        :dental_care => "Dental Care",
        :latitude => 2.5,
        :longitude => 3.5,
        :geojson => ""
      )
    ])
  end

  it "renders a list of ubs" do
    render
    assert_select "tr>td", :text => "Cnes".to_s, :count => 2
    assert_select "tr>td", :text => "Name".to_s, :count => 2
    assert_select "tr>td", :text => "Adress".to_s, :count => 2
    assert_select "tr>td", :text => "Cep".to_s, :count => 2
    assert_select "tr>td", :text => "Unity Type".to_s, :count => 2
    assert_select "tr>td", :text => "Working Hours".to_s, :count => 2
    assert_select "tr>td", :text => "Drugstore".to_s, :count => 2
    assert_select "tr>td", :text => "Dental Care".to_s, :count => 2
    assert_select "tr>td", :text => 2.5.to_s, :count => 2
    assert_select "tr>td", :text => 3.5.to_s, :count => 2
    assert_select "tr>td", :text => "".to_s, :count => 2
  end
end
