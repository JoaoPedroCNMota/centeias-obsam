require 'rails_helper'

RSpec.describe "ubs/new", type: :view do
  before(:each) do
    assign(:ub, Ub.new(
      :cnes => "MyString",
      :name => "MyString",
      :adress => "MyString",
      :cep => "MyString",
      :unity_type => "MyString",
      :working_hours => "MyString",
      :drugstore => "MyString",
      :dental_care => "MyString",
      :latitude => 1.5,
      :longitude => 1.5,
      :geojson => ""
    ))
  end

  it "renders new ub form" do
    render

    assert_select "form[action=?][method=?]", ubs_path, "post" do

      assert_select "input[name=?]", "ub[cnes]"

      assert_select "input[name=?]", "ub[name]"

      assert_select "input[name=?]", "ub[adress]"

      assert_select "input[name=?]", "ub[cep]"

      assert_select "input[name=?]", "ub[unity_type]"

      assert_select "input[name=?]", "ub[working_hours]"

      assert_select "input[name=?]", "ub[drugstore]"

      assert_select "input[name=?]", "ub[dental_care]"

      assert_select "input[name=?]", "ub[latitude]"

      assert_select "input[name=?]", "ub[longitude]"

      assert_select "input[name=?]", "ub[geojson]"
    end
  end
end
