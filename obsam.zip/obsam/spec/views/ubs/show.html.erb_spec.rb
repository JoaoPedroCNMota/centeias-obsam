require 'rails_helper'

RSpec.describe "ubs/show", type: :view do
  before(:each) do
    @ub = assign(:ub, Ub.create!(
      :cnes => "Cnes",
      :name => "Name",
      :adress => "Adress",
      :cep => "Cep",
      :unity_type => "Unity Type",
      :working_hours => "Working Hours",
      :drugstore => "Drugstore",
      :dental_care => "Dental Care",
      :latitude => 2.5,
      :longitude => 3.5,
      :geojson => ""
    ))
  end

  it "renders attributes in <p>" do
    render
    expect(rendered).to match(/Cnes/)
    expect(rendered).to match(/Name/)
    expect(rendered).to match(/Adress/)
    expect(rendered).to match(/Cep/)
    expect(rendered).to match(/Unity Type/)
    expect(rendered).to match(/Working Hours/)
    expect(rendered).to match(/Drugstore/)
    expect(rendered).to match(/Dental Care/)
    expect(rendered).to match(/2.5/)
    expect(rendered).to match(/3.5/)
    expect(rendered).to match(//)
  end
end
