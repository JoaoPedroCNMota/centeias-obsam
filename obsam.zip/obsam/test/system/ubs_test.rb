require "application_system_test_case"

class UbsTest < ApplicationSystemTestCase
  # test "visiting the index" do
  #   visit ubs_url
  #
  #   assert_selector "h1", text: "Ub"
  # end
end
